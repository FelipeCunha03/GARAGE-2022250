/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.VanMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.VanTypes;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Van;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.VanRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 * VanController, responsible for handling various operations related to buses in a garage application
 */
@Controller
@RequestMapping("/van") // Base URL mapping for all van-related operations
public class VanController {

    @Autowired
    VanRepository vanRepository;

    @Autowired
    ClientRepository clientRepository;

    // Handler for GET request to register a new van
    @GetMapping("/RegisterVan")
    public ModelAndView registerVanGet(Van van) {
        // Create a ModelAndView instance with the view name "van/RegisterVan"
        ModelAndView mv = new ModelAndView("van/RegisterVan");

        // Add the "van" object to the model, which is used to bind form data
        mv.addObject("van", van);

        // Add enum values to the model for dropdown selection in the registration form
        // The following enums are assumed to exist: VanMakes, VanTypes, EngineTypes
        mv.addObject("vanMakes", VanMakes.values()); // Enum values for van makes
        mv.addObject("vanTypes", VanTypes.values()); // Enum values for van types
        mv.addObject("engineTypes", EngineTypes.values()); // Enum values for engine types

        return mv;
    }

    // Handler for POST request to register a new van
    @PostMapping("/RegisterVan")
    public RedirectView registerVan(@ModelAttribute Van van, @RequestParam("id") Long id) {
        // Declare a Client variable
        Client client;

        // Retrieve the client from the clientRepository using the provided id
        // If the client is not found, throw a UsernameNotFoundException
        client = clientRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Set the retrieved client for the van
        van.setClient(client);

        // Create a ModelAndView instance with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Add the "Van" object to the model
        mv.addObject("Van", van);

        // Save the van object to the vanRepository
        vanRepository.save(van);

        // Return a RedirectView to the root path "/"
        return new RedirectView("/");
    }

    // Handler for GET request to edit a specific van
    @GetMapping("/editVan/{id}")
    public ModelAndView editVan(@PathVariable("id") Long id) {
        // Create a ModelAndView instance with the view name "van/editVan"
        ModelAndView mv = new ModelAndView("van/editVan");

        // Retrieve the van with the specified id from the vanRepository
        // and add it to the model with the key "van"
        mv.addObject("van", vanRepository.findById(id));

        // Add the enum values of VanMakes, VanTypes, and EngineTypes to the model
        mv.addObject("vanMakes", VanMakes.values());
        mv.addObject("vanTypes", VanTypes.values());
        mv.addObject("engineTypes", EngineTypes.values());

        // Return the ModelAndView instance
        return mv;
    }

    // Handler for POST request to edit/update a van
    @PostMapping("/editVan")
    public RedirectView editVan(Van van) {
        // Save the updated van information to the vanRepository
        vanRepository.save(van);

        // Return a RedirectView to the root URL ("/") after the edit is complete
        return new RedirectView("/");
    }

    // Handler for GET request to delete a van
    @GetMapping("/deleteVan/{id}")
    public RedirectView deleteVan(@PathVariable("id") Long id) {
        // Delete the van with the specified ID from the vanRepository
        vanRepository.deleteById(id);

        // Return a RedirectView to the root URL ("/") after the van is deleted
        return new RedirectView("/");
    }

    // Handler for GET request to list vans associated with a client
    @GetMapping("/listVan")
    public ModelAndView listVan(@RequestParam("id") Long id) {
        // Create a new ModelAndView object for the "listVan" view
        ModelAndView mv = new ModelAndView("/van/listVan");

        // Retrieve the list of vans associated with the client ID
        // using the vanRepository's findByClientId method
        mv.addObject("vans", vanRepository.findByClientId(id));

        // Return the ModelAndView object to render the "listVan" view
        return mv;
    }
}
