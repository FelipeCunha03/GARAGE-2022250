/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.MotorbikeMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.MotorbikeTypes;
import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_MOTORBIKES") // Specifies the name of the database table
public class Motorbike extends Vehicles {

    // Represents the cylinder capacity of the motorbike
    private Integer cylinderCapacity;

    // Represents the make (brand) of the motorbike
    @Enumerated(EnumType.STRING)
    private MotorbikeMakes motorbikeMake;

    // Represents the type of the motorbike (e.g., cruiser, sport, etc.)
    @Enumerated(EnumType.STRING)
    private MotorbikeTypes motorbikeType;

    // Represents the client (owner) of the motorbike
    @ManyToOne
    @JoinColumn(name = "client_id_fk") // Specifies the column for the client's ID in the database table
    private Client client;

    // Constructor for creating a new Motorbike instance with specified attributes
    public Motorbike(Integer cylinderCapacity, MotorbikeMakes motorBikeMake, MotorbikeTypes motorBikesType, Client client, Integer year, String color, String plate, EngineTypes engineType) {
        // Call the constructor of the superclass (Vehicles) to initialize vehicle attributes
        super(year, color, plate, engineType);
        this.cylinderCapacity = cylinderCapacity;
        this.motorbikeMake = motorBikeMake;
        this.motorbikeType = motorBikesType;
        this.client = client;
    }

    // Default constructor for the Motorbike class
    public Motorbike() {
    }

}

