/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 *
 * @author felipecunha
 */// This annotation indicates that the class is a JPA entity, which maps to a database table.
@Entity
@Getter
@Setter
public class BookCar extends BookService {

    // This annotation establishes a many-to-one relationship with the "Car" entity.
    // The "JoinColumn" annotation specifies the foreign key column in the database.
    @ManyToOne
    @JoinColumn(name = "car_id_fk")
    private Car car;

    // Similar to the previous relationship, this associates a "Mechanic" with a "BookCar".
    @ManyToOne
    @JoinColumn(name = "mechanic_id_fk")
    private Mechanic mechanic;

    // Another many-to-one relationship, this time linking a "Client" with a "BookCar".
    @ManyToOne
    @JoinColumn(name = "client_id_fk")
    private Client client;

    // These fields represent various cost-related attributes of the car service booking.
    private double generalCost;
    private double extralCost; // Note: "extralCost" should probably be spelled as "extraCost".
    private String CarServiceDetails; // Details of the car service.
    private double finalCost; // The final calculated cost.

    // Constructor for creating a new "BookCar" instance with all necessary details.
    // It calls the constructor of the superclass ("BookService") using "super(...)".
    public BookCar(Car car, Mechanic mechanic, Client client, double generalCost, double extralCost, String CarServiceDetails, double finalCost, TypeService typeService, String details, String timeIn, Date dateService, StatusService statusService) {
        super(typeService, details, timeIn, dateService, statusService);
        this.car = car;
        this.mechanic = mechanic;
        this.client = client;
        this.generalCost = generalCost;
        this.extralCost = extralCost;
        this.CarServiceDetails = CarServiceDetails;
        this.finalCost = finalCost;
    }

    // Default constructor, typically used in JPA entities.
    public BookCar() {
    }
}


 

   


