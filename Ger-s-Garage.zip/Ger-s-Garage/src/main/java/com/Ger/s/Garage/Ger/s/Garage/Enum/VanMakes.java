/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum VanMakes {

    FordTransitConnect("FordTransitConnect"),
    VolkswagenCaddy("VolkswagenCaddy"),
    CitroënBerlingo("CitroënBerlingo"),
    RenaultKangoo("RenaultKangoo"),
    MercedesBenzCitan("MercedesBenzCitan"),
    NissanNV200("NissanNV200"),
    ToyotaProaceCity("ToyotaProaceCity");

    private String vanMake;

    private VanMakes(String vanMake) {
        this.vanMake = vanMake;
    }

    public String getVanMake() {
        return vanMake;
    }

    public void setVanMake(String vanMake) {
        this.vanMake = vanMake;
    }

}
