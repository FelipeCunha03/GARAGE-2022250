/*
 * This class implements the UserDetails interface from Spring Security and is used to provide details about 
a Mechanic user for authentication and authorization purposes.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.model.Mechanic;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Custom implementation of UserDetails for Mechanic users.
 */
public class MechanicDetailsImpl implements UserDetails {

    private final Mechanic mechanic;

    // Constructor to set the Mechanic instance
    public MechanicDetailsImpl(Mechanic mechanic) {
        this.mechanic = mechanic;
    }

    // Get the ID of the Mechanic
    public long getId() {
        return mechanic.getId();
    }

    // Get the first name of the Mechanic
    public String getName() {
        return mechanic.getFirstName();
    }

    // Retrieve the authorities (roles) for the Mechanic
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Profile profile = mechanic.getProfile();

        // Determine the authority based on the Mechanic's profile
        if (profile == Profile.ADM) {
            profile = Profile.ADM;
        } else {
            profile = Profile.MECHANIC;
        }

        // Create a list of authorities with the profile as a role
        return AuthorityUtils.createAuthorityList(profile.toString());
    }

    // Get the password of the Mechanic
    @Override
    public String getPassword() {
        return mechanic.getPassword();
    }

    // Get the email (username) of the Mechanic
    @Override
    public String getUsername() {
        return mechanic.getEmail();
    }

    // Mechanic accounts are always considered as non-expired, non-locked, and non-credentials-expired
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    // Mechanic accounts are always considered as enabled
    @Override
    public boolean isEnabled() {
        return true;
    }
}
