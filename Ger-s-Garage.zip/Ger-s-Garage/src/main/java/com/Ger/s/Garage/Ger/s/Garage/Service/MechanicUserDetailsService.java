/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Mechanic;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;

import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *
 * @author felipecunha
 */
@Service
public class MechanicUserDetailsService implements UserDetailsService {

    @Autowired
    private MechanicRepository mechanicRepository;
    
    // This method is an override of the loadUserByUsername method from the interface.
// It retrieves an Mechanic entity by email from the repository and returns an MechanicDetailsImpl object.
// If the user is not found, a UsernameNotFoundException is thrown.

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Mechanic mechanic = mechanicRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return new MechanicDetailsImpl(mechanic);

    }

}
