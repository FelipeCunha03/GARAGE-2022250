/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import com.Ger.s.Garage.Ger.s.Garage.Service.BookServiceImp;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookMotorbikeInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookVanInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.model.BookBus;
import com.Ger.s.Garage.Ger.s.Garage.model.BookCar;
import com.Ger.s.Garage.Ger.s.Garage.model.BookMotorbike;
import com.Ger.s.Garage.Ger.s.Garage.model.BookVan;
import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import com.Ger.s.Garage.Ger.s.Garage.model.Car;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Van;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.VanRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestParam;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 *
 * /**
 * This is the main controller class for handling VAN-related operations. The
 * controller handles various HTTP endpoints for booking van services. It uses
 * Spring MVC annotations for mapping requests to methods. The class defines
 * methods to register, edit, list, and delete booked car services, as well as
 * generate invoices for the services. The class is annotated with @Controller
 * to indicate that it's a Spring MVC controller.
 */
@Controller
@RequestMapping("/van")
public class BookVanController {

    BookServiceImp bookServiceImp = new BookServiceImp();

     // Autowired repositories for accessing data
    @Autowired
    private BookVanRepository bookVanRepository;

    @Autowired
    private VanRepository vanRepository;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MechanicRepository mechanicRepository;

    @Autowired
    private BookCarRepository bookCarRepository;

    @Autowired
    private BookBusRepository bookBusRepository;

    @Autowired
    private BookMotorbikeRepository bookMotorbikeRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private MotorbikeRepository motorbikeRepository;

    // Handler for GET request to register a van service booking
    @GetMapping("/registerBookServiceVan/{id}")
    public ModelAndView registerBookServiceBus(BookVan bookVan, @PathVariable("id") Long idVan) {
        // Create a ModelAndView instance with the view name "van/registerBookServiceVan"
        ModelAndView mv = new ModelAndView("van/registerBookServiceVan");

        // Add attributes to the ModelAndView object
        mv.addObject("bookVan", bookVan); // Add a "bookVan" attribute, which represents the booking details
        mv.addObject("idVan", idVan); // Add an "idVan" attribute, which represents the ID of the van for the booking
        mv.addObject("typeServices", TypeService.values()); // Add a "typeServices" attribute, representing available service types

        return mv; // Return the ModelAndView object
    }

    // Handler for POST request to register a van service booking
    @PostMapping("/registerBookServiceVan")
    public RedirectView registerBookServiceBus(@ModelAttribute BookVan bookVan, @RequestParam("id") Long idClient, @ModelAttribute("idVan") Long idVan) {
        // Calculate the total number of booked services for the requested day
        long countCar, countVan, countBus, countMotorbike, amountBooks;

        // Count the number of bookings for each vehicle type on the requested day
        countCar = bookCarRepository.findBookCarByday(bookVan.getStatusService(), bookVan.getDateService());
        countVan = bookVanRepository.findBookVanByday(bookVan.getStatusService(), bookVan.getDateService());
        countBus = bookBusRepository.findBookBusByday(bookVan.getStatusService(), bookVan.getDateService());
        countMotorbike = bookMotorbikeRepository.findBookMotorbikeByday(bookVan.getStatusService(), bookVan.getDateService());

        // Calculate the total number of bookings
        amountBooks = countCar + countVan + countBus + countMotorbike;

        // Check if the booking limit (6 bookings) for the day is reached
        if (amountBooks == 6) {
            // If the limit is reached, print an error message
            System.out.println("There are no available booking slots for this day");
        } else {
            // If the limit is not reached, proceed with the booking

            // Find the client by ID
            Client client = clientRepository.findById(idClient)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));
            bookVan.setClient(client);

            // Find the van by ID
            Van van = vanRepository.findById(idVan)
                    .orElseThrow(() -> new UsernameNotFoundException("Car not found"));
            bookVan.setVan(van);

            // Get the type of service selected and set the general cost
            String typeService = bookVan.getTypeService().getTypeService();
            bookVan.setGeneralCost(bookServiceImp.checkService(typeService));

            // Save the booking
            bookVanRepository.save(bookVan);
        }

        return new RedirectView("/");
    }

    // Handler for GET request to list van services for a specific client ID
    @GetMapping("/bookVan")
    public ModelAndView listVan(@RequestParam("id") Long id) {
        // Create a ModelAndView object for rendering the listVan view
        ModelAndView mv = new ModelAndView("/van/listVan");

        // Use the vanRepository to find van services for a specific client by their client ID
        // The method findByClientId(id) retrieves a list of van services associated with the given client ID
        // The retrieved list of van services is added to the ModelAndView object with the key "vans"
        mv.addObject("vans", vanRepository.findByClientId(id));

        // Return the ModelAndView object to render the view template
        return mv;
    }

    // Handler for GET request to edit a van service booking by ID
    @GetMapping("/editBookVan/{id}")
    public ModelAndView editBookVan(@PathVariable("id") Long id) {
        // Create a ModelAndView object for rendering the editBookVan view
        ModelAndView mv = new ModelAndView("van/editBookVan");

        // Use the bookVanRepository to find the van service booking by its ID
        // The method findById(id) retrieves the van service booking with the given ID
        // The retrieved van service booking is added to the ModelAndView object with the key "bookVan"
        mv.addObject("bookVan", bookVanRepository.findById(id));

        // Add the possible values of status services to the ModelAndView object
        // StatusService.values() retrieves an array of possible status service values
        mv.addObject("statusServices", StatusService.values());

        // Add the possible values of type services to the ModelAndView object
        // TypeService.values() retrieves an array of possible type service values
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView object to render the editBookVan view template
        return mv;
    }

    // Handler for POST request to update a van service booking
    @PostMapping("/editBookVan")
    public RedirectView editBookMotorbike(BookVan bookVan) {
        // Update the final cost of the van service booking by calling a method from bookServiceImp
        // The method updateFinalCost() calculates the final cost based on the extra cost and general cost
        bookVan.setFinalCost(bookServiceImp.updateFinalCost(bookVan.getExtralCost(), bookVan.getGeneralCost()));

        // Save the updated van service booking using the bookVanRepository
        bookVanRepository.save(bookVan);

        // Return a RedirectView to the home page ("/") after the update is complete
        return new RedirectView("/");
    }

    // Handler for GET request to edit a van service booking by a mechanic user
    @GetMapping("/editBookVanMechanicUser/{id}")
    public ModelAndView editBookCarMechanicUser(@PathVariable("id") Long id) {
        // Create a new ModelAndView object with the view name "van/editBookVan"
        ModelAndView mv = new ModelAndView("van/editBookVan");

        // Add the following objects to the ModelAndView:
        // 1. "bookVan": The van service booking retrieved from the bookVanRepository by its ID
        // 2. "statusServices": An array of all values in the StatusService enum
        // 3. "typeServices": An array of all values in the TypeService enum
        // 4. "mechanics": A list of all mechanics retrieved from the mechanicRepository
        // These objects are intended to be used in the view to populate form fields and provide options.
        mv.addObject("bookVan", bookVanRepository.findById(id)); // Retrieve the specific van service booking
        mv.addObject("statusServices", StatusService.values()); // Populate status service options
        mv.addObject("typeServices", TypeService.values()); // Populate type service options
        mv.addObject("mechanics", mechanicRepository.findAll()); // Retrieve all mechanics

        // Return the ModelAndView object, which contains the view name and the added objects
        return mv;
    }

    // Handler for GET request to update the status of a van service booking by an admin user
    @GetMapping("/editBookVanAdminUser/{id}")
    public ModelAndView updateStatusBookVan(@PathVariable("id") Long id) {
        // Create a new ModelAndView object with the view name "van/editBookVan"
        ModelAndView mv = new ModelAndView("van/editBookVan");

        // Add the following objects to the ModelAndView:
        // 1. "bookVan": The van service booking retrieved from the bookVanRepository by its ID
        // 2. "statusServices": An array of all values in the StatusService enum
        // 3. "typeServices": An array of all values in the TypeService enum
        // 4. "mechanics": A list of all mechanics retrieved from the mechanicRepository
        // These objects are intended to be used in the view to populate form fields and provide options.
        mv.addObject("bookVan", bookVanRepository.findById(id)); // Retrieve the specific van service booking
        mv.addObject("statusServices", StatusService.values()); // Populate status service options
        mv.addObject("typeServices", TypeService.values()); // Populate type service options
        mv.addObject("mechanics", mechanicRepository.findAll()); // Retrieve all mechanics

        // Return the ModelAndView object, which contains the view name and the added objects
        return mv;
    }

    // Handler for GET request to delete a van service booking
    @GetMapping("/deleteBookVan/{id}")
    public RedirectView deleteBookVan(@PathVariable("id") Long id) {
        // Delete the van service booking from the bookVanRepository by its ID
        bookVanRepository.deleteById(id);

        // Redirect to the home page ("/") after deleting the booking
        return new RedirectView("/");
    }

    // Handler for GET request to list booked van services
    @GetMapping("/listVanBooked")
    public ModelAndView listVanBooked() {
        // Create a ModelAndView object to render the view "van/listVanBooked"
        ModelAndView mv = new ModelAndView("/van/listVanBooked");

        // Add the list of booked van services to the ModelAndView
        mv.addObject("bookVans", bookVanRepository.findAll());

        // Return the ModelAndView to render the list of booked van services view
        return mv;
    }

    // Handler for GET request to generate an invoice for a booked van service
    @GetMapping("/generateInvoiceBookVan/{id}")
    public void exportToPDF(HttpServletResponse response, @PathVariable("id") Long id) throws DocumentException, IOException {
        // Set the response content type to indicate that the response will be a PDF document
        response.setContentType("application/pdf");

        // Create a date formatter to generate a unique timestamp for the PDF file name
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        // Set the "Content-Disposition" header to specify the filename for the downloaded PDF
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=invoice" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);

        // Fetch the booked van service by its ID from the repository
        BookVan bookVan;
        bookVan = bookVanRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Create an instance of the PDF invoice generator for the booked van service
        GenerateBookVanInvoicePDF exporter = new GenerateBookVanInvoicePDF(bookVan);

        // Export the invoice as a PDF and write it to the response output stream
        exporter.export(response);
    }

}

// 
