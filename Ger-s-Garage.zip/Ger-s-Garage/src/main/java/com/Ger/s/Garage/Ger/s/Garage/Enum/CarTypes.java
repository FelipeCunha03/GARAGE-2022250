/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum CarTypes {

    // list of types of cars from makes Volkswagen
    VolkswagenGolf("VolkswagenGolf"),
    VolkswagenPassat("VolkswagenPassat"),
    VolkswagenPolo("VolkswagenPolo"),
    VolkswagenJetta("VolkswagenTCross"),
    VolkswagenTiguan("VolkswagenTiguan"),
    VolkswagenTouareg("VolkswagenTouareg"),
    VolkswagenAtlas("VolkswagenAtlas"),
    VolkswagenBeetle("VolkswagenBeetle"),
    VolkswagenID4("VolkswagenID4"),
    VolkswagenAmarok("VolkswagenAmarok"),
    VolkswagenUp("VolkswagenUp"),
    // list of types of cars from makes Audi
    AudiA3("AudiA3"),
    AudiA4("AudiA4"),
    AudiA6("AudiA6"),
    AudiA8("AudiA8"),
    AudiQ3("AudiQ3"),
    AudiQ5("AudiQ5"),
    AudiQ7("AudiQ7"),
    AudiQ8("AudiQ8"),
    AudiTT("AudiTT"),
    AudiR8("AudiR8"),
    AudiRSmodels("AudiRSmodels"),
    Audietron("Audietron"),
    // list of types of cars from makes BMW
    BMW3Series("BMW3Series"),
    BMW5Series("BMW5Series"),
    BMW7Series("BMW7Series"),
    BMWX1("BMWX1"),
    BMWX3("BMWX3"),
    BMWX5("BMWX5"),
    BMWX7("BMWX7"),
    BMWZ4("BMWZ4"),
    BMWi3("BMWi3"),
    BMWM2("BMWM2"),
    BMWM3("BMWM3"),
    BMWM5("BMWM5"),
    BMWM8("BMWM8"),
    // list of types of cars from makes MercedesBenz
    MercedesBenzAClass("MercedesBenzAClass"),
    MercedesBenzCClass("MercedesBenzCClass"),
    MercedesBenzEClass("MercedesBenzEClass"),
    MercedesBenzSClass("MercedesBenzSClass"),
    MercedesBenzGLA("MercedesBenzGLA"),
    MercedesBenzGLC("MercedesBenzGLC"),
    MercedesBenzGLE("MercedesBenzGLE"),
    MercedesBenzGLS("MercedesBenzGLS"),
    MercedesBenzCLA("MercedesBenzCLA"),
    MercedesBenzCLS("MercedesBenzCLS"),
    MercedesBenzSLK("MercedesBenzSLK"),
    MercedesBenzSL("MercedesBenzSL"),
    MercedesBenzAMGGT("MercedesBenzAMGGT"),
    MercedesBenzEQC("MercedesBenzEQC"),
    // list of types of cars from makes Volvo
    VolvoS60("VolvoS60"),
    VolvoS90("VolvoS90"),
    VolvoV60("VolvoV60"),
    VolvoV90("VolvoV90"),
    VolvoXC40("VolvoXC40"),
    VolvoXC60("VolvoXC60"),
    VolvoXC90("VolvoXC90"),
    VolvoV40("VolvoV40"),
    VolvoV40CrossCountry("VolvoV40CrossCountry"),
    VolvoV60CrossCountry("VolvoV60CrossCountry"),
    VolvoV90CrossCountry("VolvoV90CrossCountry"),
    VolvoPolestarmodels("VolvoPolestarmodels"),
    // list of types of cars from makes Fiat
    Fiat500("Fiat500"),
    FiatPanda("FiatPanda"),
    FiatTipo("FiatTipo"),
    Fiat500X("Fiat500X"),
    Fiat500L("Fiat500L"),
    Fiat124Spider("Fiat124Spider"),
    FiatDoblo("FiatDoblo"),
    FiatQubo("FiatQubo"),
    FiatFiorino("FiatFiorino"),
    FiatDucato("FiatDucato"),
    // list of types of cars from makes Renault
    RenaultClio("RenaultClio"),
    RenaultMegane("RenaultMegane"),
    RenaultCaptur("RenaultCaptur"),
    RenaultKadjar("RenaultKadjar"),
    RenaultScenic("RenaultScenic"),
    RenaultTalisman("RenaultTalisman"),
    RenaultZoe("RenaultZoe"),
    RenaultTwingo("RenaultTwingo"),
    RenaultKoleos("RenaultKoleos"),
    RenaultEspace("RenaultEspace"),
    RenaultKangoo("RenaultKangoo"),
    RenaultFluence("RenaultFluence"),
    // list of types of cars from makes Lamborghini
    LamborghiniAventador("LamborghiniAventador"),
    LamborghiniHuracan("LamborghiniHuracan"),
    LamborghiniUrus("LamborghiniUrus"),
    LamborghiniGallardo("LamborghiniGallardo"),
    LamborghiniMurcielago("LamborghiniMurcielago"),
    LamborghiniDiablo("LamborghiniDiablo"),
    LamborghiniCentenario("LamborghiniCentenario"),
    LamborghiniVeneno("LamborghiniVeneno"),
    LamborghiniSestoElemento("LamborghiniSestoElemento"),
    LamborghiniReventon("LamborghiniReventon");

    private String carType;

    private CarTypes(String TypesCars) {
        this.carType = TypesCars;
    }

    public String getTypesCars() {
        return carType;
    }

    public void setTypesCars(String TypesCars) {
        this.carType = TypesCars;
    }

}
