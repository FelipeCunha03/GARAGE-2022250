// Package declaration
package com.Ger.s.Garage.Ger.s.Garage.controller;

// Import statements
import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import com.Ger.s.Garage.Ger.s.Garage.Service.BookServiceImp;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookBusInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.model.BookBus;
import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestParam;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Controller class for managing bus bookings and related functionalities. Uses
 * Spring MVC annotations to handle HTTP requests. \/** This is the main
 * controller class for handling Bus-related operations. The controller handles
 * various HTTP endpoints for booking bus services. It uses Spring MVC
 * annotations for mapping requests to methods. The class defines methods to
 * register, edit, list, and delete booked bus services, as well as generate
 * invoices for the services. The class is annotated with @Controller to
 * indicate that it's a Spring MVC controller.
 */
@Controller
@RequestMapping("/bus")
public class BookBusController {
    
     // Autowired repositories for accessing data
     @Autowired
    private BookCarRepository bookCarRepository;

    @Autowired
    private BookVanRepository bookVanRepository;

    @Autowired
    private BookBusRepository bookBusRepository;

    @Autowired
    private BookMotorbikeRepository bookMotorbikeRepository;

    @Autowired
    private CarRepository carRepository;

    // Instantiate the BookServiceImp for handling booking services
    BookServiceImp bookServiceImp = new BookServiceImp();

    // Autowired repositories for accessing data
    @Autowired
    private BusRepository busRepository;

    

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MechanicRepository mechanicRepository;

    // This method handles a GET request to register a bus service booking
    @GetMapping("/registerBookServiceBus/{id}")
    public ModelAndView registerBookServiceBus(BookBus bookBus, @PathVariable("id") Long idBus) {
        // Create a new ModelAndView object for the view "bus/registerBookServiceBus"
        ModelAndView mv = new ModelAndView("bus/registerBookServiceBus");

        // Add the "bookBus" object to the ModelAndView, allowing it to be accessed in the view
        mv.addObject("bookBus", bookBus);

        // Add the "idBus" value (extracted from the URL) to the ModelAndView, used to identify the specific bus
        mv.addObject("idBus", idBus);

        // Add the possible values of the "TypeService" enum to the ModelAndView, used for selecting the type of service
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView, which will render the specified view with the provided data
        return mv;
    }

    // This method handles a POST request to register a bus service booking
    @PostMapping("/registerBookServiceBus")
    public RedirectView registerBookServiceBus(@ModelAttribute BookBus bookBus, @RequestParam("id") Long idClient, @ModelAttribute("idBus") Long idBus) {
        
         // Calculate the total number of booked services for the requested day
        long countCar, countVan, countBus, countMotorbike, amountBooks;

        // Count the number of bookings for each vehicle type on the requested day
        countCar = bookCarRepository.findBookCarByday(bookBus.getStatusService(), bookBus.getDateService());
        countVan = bookVanRepository.findBookVanByday(bookBus.getStatusService(), bookBus.getDateService());
        countBus = bookBusRepository.findBookBusByday(bookBus.getStatusService(), bookBus.getDateService());
        countMotorbike = bookMotorbikeRepository.findBookMotorbikeByday(bookBus.getStatusService(), bookBus.getDateService());

        // Calculate the total number of bookings
        amountBooks = countCar + countVan + countBus + countMotorbike;

        // Check if the booking limit (6 bookings) for the day is reached
        if (amountBooks == 6) {
            // If the limit is reached, print an error message
            System.out.println("There are no available booking slots for this day");
        }
            else{
        // Find the client by ID
        Client client = clientRepository.findById(idClient)
                .orElseThrow(() -> new UsernameNotFoundException("Bus not found"));
        // Set the found client for the booked bus
        bookBus.setClient(client);

        // Find the bus by ID
        Bus bus = busRepository.findById(idBus)
                .orElseThrow(() -> new UsernameNotFoundException("Bus not found"));
        // Set the found bus for the booked bus
        bookBus.setBus(bus);

        // Get the type of service selected and set the general cost based on the selected type
        String typeService = bookBus.getTypeService().getTypeService();
        bookBus.setGeneralCost(bookServiceImp.checkService(typeService));

        // Save the booking by calling the repository's save method
        bookBusRepository.save(bookBus);
                    }

        // Redirect to the main page ("/") after successfully saving the booking
        return new RedirectView("/");
    }

    // This method handles a GET request to edit a bus service booking by ID
    @GetMapping("/editBookBus/{id}")
    public ModelAndView editBookBus(@PathVariable("id") Long id) {
        // Create a ModelAndView object to prepare the view and model data
        ModelAndView mv = new ModelAndView("bus/editBookBus");

        // Add the selected booking details to the model
        mv.addObject("bookBus", bookBusRepository.findById(id));

        // Add the values of StatusService enum to the model
        mv.addObject("statusServices", StatusService.values());

        // Add the values of TypeService enum to the model
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView object to render the editBookBus view
        return mv;
    }

    // This method handles a POST request to edit a bus service booking
    @PostMapping("/editBookBus")
    public RedirectView editBookBus(BookBus bookBus) {
        // Update the final cost based on extra cost and general cost
        bookBus.setFinalCost(bookServiceImp.updateFinalCost(bookBus.getExtralCost(), bookBus.getGeneralCost()));

        // Save the updated booking information to the repository
        bookBusRepository.save(bookBus);

        // Redirect the user back to the home page ("/")
        return new RedirectView("/");
    }

    // This method handles a GET request to edit a bus service booking by ID (for admin users)
    @GetMapping("/editBookBusAdminUser/{id}")
    public ModelAndView editBookCarMechanicUser(@PathVariable("id") Long id) {
        // Create a ModelAndView instance for rendering the edit booking view
        ModelAndView mv = new ModelAndView("bus/editBookBus");

        // Add attributes to the ModelAndView for rendering the edit form
        // 1. Add the existing bus service booking with the specified ID
        mv.addObject("bookBus", bookBusRepository.findById(id));
        // 2. Add the possible status values for the service (e.g., "Pending", "Completed")
        mv.addObject("statusServices", StatusService.values());
        // 3. Add the possible type of service values (e.g., "Oil Change", "Tire Replacement")
        mv.addObject("typeServices", TypeService.values());
        // 4. Add the list of mechanics (presumably for selecting a mechanic for the service)
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView, which will render the edit booking form view
        return mv;
    }

    // This method handles a GET request to edit a bus service booking by ID (for mechanic users)
    @GetMapping("/editBookBusMechanicUser/{id}")
    public ModelAndView updateStatusBookBus(@PathVariable("id") Long id) {
        // Create a ModelAndView instance for rendering the edit booking view
        ModelAndView mv = new ModelAndView("bus/editBookBus");

        // Add attributes to the ModelAndView for rendering the edit form
        // 1. Add the existing bus service booking with the specified ID
        mv.addObject("bookBus", bookBusRepository.findById(id));
        // 2. Add the possible status values for the service (e.g., "Pending", "Completed")
        mv.addObject("statusServices", StatusService.values());
        // 3. Add the possible type of service values (e.g., "Oil Change", "Tire Replacement")
        mv.addObject("typeServices", TypeService.values());
        // 4. Add the list of mechanics (presumably for selecting a mechanic for the service)
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView, which will render the edit booking form view
        return mv;
    }

    // This method handles a GET request to delete a bus service booking by ID
    @GetMapping("/deleteBookBus/{id}")
    public RedirectView deleteBookBus(@PathVariable("id") Long id) {
        // Delete the bus service booking with the specified ID from the repository
        bookBusRepository.deleteById(id);

        // Redirect to the root URL ("/") after successful deletion
        return new RedirectView("/");
    }

    // This method handles a GET request to list booked bus services
    @GetMapping("/listBusBooked")
    public ModelAndView listBusBooked() {
        // Create a ModelAndView object with the view name "bus/listBusBooked"
        ModelAndView mv = new ModelAndView("/bus/listBusBooked");

        // Add the list of booked bus services to the ModelAndView
        mv.addObject("bookBuses", bookBusRepository.findAll());

        // Return the ModelAndView, which will be used to render the view
        return mv;
    }

    // This method handles a GET request to generate and export an invoice for a booked bus service
    @GetMapping("/generateInvoiceBookBus/{id}")
    public void exportToPDF(HttpServletResponse response, @PathVariable("id") Long id) throws DocumentException, IOException {
        // Set the response content type to indicate that the response will be a PDF
        response.setContentType("application/pdf");

        // Create a date formatter to generate a timestamp for the filename
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        // Set the response header to specify the filename of the exported PDF
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=invoice" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);

        // Find the booked bus by ID
        BookBus bookBus;
        bookBus = bookBusRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Export the invoice as a PDF
        GenerateBookBusInvoicePDF exporter = new GenerateBookBusInvoicePDF(bookBus);
        exporter.export(response);
    }

}
