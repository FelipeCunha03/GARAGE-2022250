package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.model.BookVan;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing BookVan entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines custom query methods for finding BookVan entities based on various criteria.
 */
@Repository
public interface BookVanRepository extends JpaRepository<BookVan, Long> {

    /**
     * Find a list of BookVan entities by the ID of the associated client.
     * @param clientId the ID of the client
     * @return a list of BookVan entities associated with the given client ID
     */
    @Query("select b from BookVan b where b.client.id = :clientId")
    List<BookVan> findBookVanByClient(Long clientId);

    /**
     * Find a list of BookVan entities by the ID of the associated mechanic.
     * @param mechanicId the ID of the mechanic
     * @return a list of BookVan entities associated with the given mechanic ID
     */
    @Query("select b from BookVan b where b.mechanic.id = :mechanicId")
    List<BookVan> findBookVanByMechanic(Long mechanicId);

    /**
     * Count the number of BookVan entities with a specific status and date of service.
     * @param statusService the status of the service
     * @param dateService the date of the service
     * @return the count of BookVan entities with the specified status and date of service
     */
    @Query("select count(b) from BookVan b where b.statusService = :statusService and b.dateService = :dateService")
    Long findBookVanByday(StatusService statusService, Date dateService);
}
