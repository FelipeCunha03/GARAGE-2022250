package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Motorbike;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Motorbike entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom query method for finding Motorbike entities by client ID.
 */
@Repository
public interface MotorbikeRepository extends JpaRepository<Motorbike, Long> {
    
    /**
     * Find Motorbike entities by client ID.
     * @param clientId the ID of the client
     * @return a list of Motorbike entities associated with the specified client ID
     */
    @Query("select b from Motorbike b where b.client.id = :clientId")
    List<Motorbike> findByClientId(Long clientId);
}
