/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MotorbikeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author felipecunha
 */
@Controller
public class indexController {

    // Autowire repositories for booking various vehicle types
    @Autowired
    BookVanRepository bookVanRepository;
    @Autowired
    BookCarRepository bookCarRepository;
    @Autowired
    BookBusRepository bookBusRepository;
    @Autowired
    BookMotorbikeRepository bookMotorbikeRepository;

    // Autowire repositories for different vehicle types
    @Autowired
    BookCarRepository carRepository;
    @Autowired
    BusRepository busRepository;
    @Autowired
    MotorbikeRepository motorbikeRepository;

    // Handler for the root URL "/"
    @RequestMapping("/")
    public String index() {
        // Return the "index.html" view
        return "index.html";
    }

    // Handler for GET request to list vehicles booked by a client
    @GetMapping("/listVechicleBooked")
    public ModelAndView listBookVehicle(@RequestParam("id") Long id) {
        // Create a ModelAndView instance with the view name "listVechicleBooked"
        ModelAndView mv = new ModelAndView("listVechicleBooked");

        // Add lists of booked vehicles (cars, buses, vans, motorbikes) by the client to the model
        mv.addObject("bookCars", bookCarRepository.findBookCarByClient(id));
        mv.addObject("bookBuses", bookBusRepository.findBookBusByClient(id));
        mv.addObject("bookVans", bookVanRepository.findBookVanByClient(id));
        mv.addObject("bookMotorbikes", bookMotorbikeRepository.findBookMotorbikeByClient(id));

        return mv;
    }

    // Handler for GET request to list vehicles booked by a mechanic
    @GetMapping("/listVechicleBookedByMechanic")
    public ModelAndView listVechicleBookedMechanic(@RequestParam("id") Long id) {
        // Create a ModelAndView instance with the view name "listVechicleBooked"
        ModelAndView mv = new ModelAndView("listVechicleBooked");

        // Add lists of booked vehicles (cars, buses, vans, motorbikes) by the mechanic to the model
        mv.addObject("bookCars", bookCarRepository.findBookCarByMechanic(id));
        mv.addObject("bookBuses", bookBusRepository.findBookBusByMechanic(id));
        mv.addObject("bookVans", bookVanRepository.findBookVanByMechanic(id));
        mv.addObject("bookMotorbikes", bookMotorbikeRepository.findBookMotorbikeByMechanic(id));

        return mv;
    }
}
