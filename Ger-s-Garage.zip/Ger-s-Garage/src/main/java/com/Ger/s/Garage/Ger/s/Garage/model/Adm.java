/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;


import javax.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import javax.persistence.Table;

/**
 *
 * @author felipecunha
 * 
 * // The following annotations are used:
//  @Getter: Generates getter methods for all non-static fields in the class.
//  @Setter: Generates setter methods for all non-static fields in the class.
// @Entity: Indicates that this class is a JPA entity, representing a database table.
// // The class "Adm" extends the "User" class, inheriting attributes and behavior from it.
* // The class does not define any additional fields or methods, as it inherits from "User."
 */
@Getter
@Setter
@Entity
@Table(name = "TB_ADM")
public class Adm  extends User {
    

    public Adm(String firtName, String lastName, long phoneNumber, String address, String password, String email,Profile profile) {
        super(firtName, lastName, phoneNumber, address, password, email, profile);
    }

    public Adm() {
    }

    
}
