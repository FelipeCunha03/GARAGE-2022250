/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import java.util.Date;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
public class BookVan extends BookService {

    // Represents the associated van for this booking
    @ManyToOne
    @JoinColumn(name = "van_id_fk")
    private Van van;

    // Represents the associated mechanic for this booking
    @ManyToOne
    @JoinColumn(name = "mechanic_id_fk")
    private Mechanic mechanic;

    // Represents the associated client (customer) for this booking
    @ManyToOne
    @JoinColumn(name = "client_id_fk")
    private Client client;

    // Represents the general cost of the van service
    private double generalCost;

    // Represents the extra cost of the van service
    private double extralCost;

    // Represents details specific to the van service
    private String VanServiceDetails;

    // Represents the final cost of the van service
    private double finalCost;

    // Constructor for creating a new BookVan instance with specified attributes
    public BookVan(Van van, Mechanic mechanic, Client client, double generalCost, double extralCost, String VanServiceDetails, TypeService typeService, String details, String timeIn, Date dateService, StatusService statusService) {
        super(typeService, details, timeIn, dateService, statusService);
        this.van = van;
        this.mechanic = mechanic;
        this.client = client;
        this.generalCost = generalCost;
        this.extralCost = extralCost;
        this.VanServiceDetails = VanServiceDetails;
    }

    // Default constructor for the BookVan class
    public BookVan() {
    }
}
