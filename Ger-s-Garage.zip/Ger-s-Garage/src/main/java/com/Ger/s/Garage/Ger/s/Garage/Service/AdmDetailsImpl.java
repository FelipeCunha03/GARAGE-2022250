/*
 * This class implements the UserDetails interface from Spring Security and is used to provide details about an ADM user (administrator) for authentication and authorization purposes.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Custom implementation of UserDetails for ADM users (administrators).
 */
public class AdmDetailsImpl implements UserDetails {

    private final Adm adm;

    // Constructor to set the Adm instance
    public AdmDetailsImpl(Adm adm) {
        this.adm = adm;
    }

    // Get the ID of the Adm (administrator)
    public long getId() {
        return adm.getId();
    }

    // Get the first name of the Adm
    public String getName() {
        return adm.getFirstName();
    }

    /*
     * This method overrides the getAuthorities() method from the superclass.
     * It returns a collection of GrantedAuthority based on the profile.
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Profile profile = adm.getProfile();

        // Create a list of authorities with the profile as a role
        return AuthorityUtils.createAuthorityList(profile.toString());
    }

    // Get the password of the Adm
    @Override
    public String getPassword() {
        return adm.getPassword();
    }

    // Get the email (username) of the Adm
    @Override
    public String getUsername() {
        return adm.getEmail();
    }

    // Adm accounts are always considered as non-expired, non-locked, and non-credentials-expired
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    // Adm accounts are always considered as enabled
    @Override
    public boolean isEnabled() {
        return true;
    }
}
