/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.ListVehicle;
import com.Ger.s.Garage.Ger.s.Garage.Enum.MotorbikeMakes;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_MECHANIC") // Specifies the name of the database table
public class Mechanic extends User {

    // Represents the unique PPS (Personal Public Service) number of the mechanic
    @Column(name = "PPSNO", unique = true) // Specifies the column in the table and enforces uniqueness
    private String PPSNO;

    // Represents the list of vans associated with this mechanic
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Van" entity
    private List<Van> van = new ArrayList();

    // Represents the list of buses associated with this mechanic
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Bus" entity
    private List<Bus> bus = new ArrayList();

    // Represents the list of motorbikes associated with this mechanic
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Motorbike" entity
    private List<Motorbike> motorbikes = new ArrayList();

    // Represents the list of cars associated with this mechanic
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Car" entity
    private List<Car> car = new ArrayList();

    // Constructor for creating a new Mechanic instance with specified attributes
    public Mechanic(String PPSNO, String firstName, String lastName, long phoneNumber, String address, String password, String email, Profile profile) {
        // Call the constructor of the superclass (User) to initialize user attributes
        super(firstName, lastName, phoneNumber, address, password, email, profile);
        this.PPSNO = PPSNO;
    }

    // Default constructor for the Mechanic class
    public Mechanic() {
    }

}
