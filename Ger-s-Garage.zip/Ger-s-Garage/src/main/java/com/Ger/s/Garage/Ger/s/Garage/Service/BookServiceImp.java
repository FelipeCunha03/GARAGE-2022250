/*
 * This class provides booking-related services for a garage management system.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Service implementation for handling garage booking operations.
 */
public class BookServiceImp {

    @Autowired
    BookCarRepository bookCarRepository;

    @Autowired
    BookBusRepository bookBusRepository;
    BookVanRepository bookVanRepository;
    BookMotorbikeRepository bookMotorbikeRepository;

    /*
     * This method calculates the general cost based on the type of service.
     * The cost is determined by a switch statement that maps service types to specific costs.
     * The calculated general cost is returned.
     */
    public double checkService(String typeService) {

        double generalCost = 0;

        switch (typeService) {
            case "AnnualService":
                generalCost = 200;
                break;

            case "MajorService":
                generalCost = 300;
                break;

            case "Repair_Fault":
                generalCost = 150;
                break;

            case "MajorRepair":
                generalCost = 500;
                break;
        }

        return generalCost;
    }

    /*
     * This method updates the final cost by adding the extra cost to the general cost.
     * The updated final cost is returned.
     */
    public double updateFinalCost(double extraCost, double generalCost) {

        double finalCost = generalCost + extraCost;

        return finalCost;
    }

    /*
     * This method checks the availability of books in the book car repository.
     * It counts the number of books and returns the count.
     */
    public Long checkBookAvailable() {

        Long amountBookCar = bookCarRepository.count();

        return amountBookCar;
    }
}
