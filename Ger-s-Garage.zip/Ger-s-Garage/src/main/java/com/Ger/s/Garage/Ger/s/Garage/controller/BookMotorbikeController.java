/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import com.Ger.s.Garage.Ger.s.Garage.Service.BookServiceImp;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookCarInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookMotorbikeInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.model.BookBus;
import com.Ger.s.Garage.Ger.s.Garage.model.BookCar;
import com.Ger.s.Garage.Ger.s.Garage.model.BookMotorbike;
import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Motorbike;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;

import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.VanRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestParam;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 */
/**
 * This is the main controller class for handling motorbike-related operations.
 * The controller handles various HTTP endpoints for booking motorbike services.
 * It uses Spring MVC annotations for mapping requests to methods. The class
 * defines methods to register, edit, list, and delete booked motorbike
 * services, as well as generate invoices for the services. The class is
 * annotated with @Controller to indicate that it's a Spring MVC controller.
 */
@Controller
@RequestMapping("/motorbike")
public class BookMotorbikeController {

    BookServiceImp bookServiceImp = new BookServiceImp();

     // Autowired repositories for accessing data
    @Autowired
    private BookCarRepository bookCarRepository;

    @Autowired
    private BookVanRepository bookVanRepository;

    @Autowired
    private BookBusRepository bookBusRepository;

    @Autowired
    private BookMotorbikeRepository bookMotorbikeRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private MotorbikeRepository motorbikeRepository;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MechanicRepository mechanicRepository;

    // Handler for GET request to register a motorbike service booking
    @GetMapping("/registerBookServiceMotorbike/{id}")
    public ModelAndView registerBookServiceMotorbike(BookMotorbike bookMotorbike, @PathVariable("id") Long idMotorbike) {
        // Create a ModelAndView object for the registration view
        ModelAndView mv = new ModelAndView("motorbike/registerBookServiceMotorbike");

        // Add attributes to the ModelAndView object
        // 1. The "motorbike" attribute is set to the provided "bookMotorbike" object
        mv.addObject("motorbike", bookMotorbike);
        // 2. The "idMotorbike" attribute is set to the value extracted from the URL path variable
        mv.addObject("idMotorbike", idMotorbike);
        // 3. The "typeServices" attribute is set to the values of the TypeService enum
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView object, which specifies the view to render and the model attributes
        return mv;
    }

    // Handler for POST request to register a motorbike service booking
    @PostMapping("/registerBookServiceMotorbike")
    public RedirectView registerBookServiceMotorbike(@ModelAttribute BookMotorbike bookMotorbike, @RequestParam("id") Long idClient, @ModelAttribute("idMotorbike") Long idMotorbike) {

        // Calculate the total number of booked services for the requested day
        long countCar, countVan, countBus, countMotorbike, amountBooks;

        // Count the number of bookings for each vehicle type on the requested day
        countCar = bookCarRepository.findBookCarByday(bookMotorbike.getStatusService(), bookMotorbike.getDateService());
        countVan = bookVanRepository.findBookVanByday(bookMotorbike.getStatusService(), bookMotorbike.getDateService());
        countBus = bookBusRepository.findBookBusByday(bookMotorbike.getStatusService(), bookMotorbike.getDateService());
        countMotorbike = bookMotorbikeRepository.findBookMotorbikeByday(bookMotorbike.getStatusService(), bookMotorbike.getDateService());

        // Calculate the total number of bookings
        amountBooks = countCar + countVan + countBus + countMotorbike;

        // Check if the booking limit (6 bookings) for the day is reached
        if (amountBooks == 6) {
            // If the limit is reached, print an error message
            System.out.println("There are no available booking slots for this day");
        } else {
            // Find the client by ID
            Client client = clientRepository.findById(idClient)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));

            // Set the client for the motorbike service booking
            bookMotorbike.setClient(client);

            // Find the motorbike by ID
            Motorbike motorbike = motorbikeRepository.findById(idMotorbike)
                    .orElseThrow(() -> new UsernameNotFoundException("Motorbike not found"));

            // Set the motorbike for the motorbike service booking
            bookMotorbike.setMotorbike(motorbike);

            // Get the type of service selected and set the general cost using the BookServiceImp
            String typeService = bookMotorbike.getTypeService().getTypeService();
            bookMotorbike.setGeneralCost(bookServiceImp.checkService(typeService));

            // Save the motorbike service booking to the repository
            bookMotorbikeRepository.save(bookMotorbike);
        }

        // Redirect to the home page ("/")
        return new RedirectView("/");
    }

    // Handler for GET request to edit a motorbike service booking by ID
    @GetMapping("/editBookMotorbike/{id}")
    public ModelAndView editBookMotorbike(@PathVariable("id") Long id) {
        // Create a ModelAndView object and specify the view name
        ModelAndView mv = new ModelAndView("motorbike/editBookMotorbike");

        // Find the motorbike service booking by ID
        mv.addObject("bookMotorbike", bookMotorbikeRepository.findById(id));

        // Add the enum values for status services to the ModelAndView
        mv.addObject("statusServices", StatusService.values());

        // Add the enum values for type services to the ModelAndView
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView with the data
        return mv;
    }

    // Handler for POST request to edit a motorbike service booking
    @PostMapping("/editBookMotorbike")
    public RedirectView editBookMotorbike(BookMotorbike bookMotorbike) {
        // Calculate the final cost based on the extra cost and general cost
        bookMotorbike.setFinalCost(bookServiceImp.updateFinalCost(bookMotorbike.getExtralCost(), bookMotorbike.getGeneralCost()));

        // Save the updated motorbike service booking in the repository
        bookMotorbikeRepository.save(bookMotorbike);

        // Redirect to the home page ("/")
        return new RedirectView("/");
    }

    // Handler for GET request to edit a motorbike service booking by mechanic users
    @GetMapping("/editBookMotorbikeMechanicUser/{id}")
    public ModelAndView editBookCarMechanicUser(@PathVariable("id") Long id) {
        // Create a ModelAndView object for the "motorbike/editBookMotorbike" view
        ModelAndView mv = new ModelAndView("motorbike/editBookMotorbike");

        // Add the following objects as attributes to the ModelAndView:
        // 1. The motorbike service booking found by its ID
        mv.addObject("bookMotorbike", bookMotorbikeRepository.findById(id));
        // 2. Enum values for status services (assuming it's an Enum)
        mv.addObject("statusServices", StatusService.values());
        // 3. Enum values for type services (assuming it's an Enum)
        mv.addObject("typeServices", TypeService.values());
        // 4. List of mechanics (likely retrieved from a repository)
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView, which will be used to render the view
        return mv;
    }

    // Handler for GET request to edit a motorbike service booking by admin users
    @GetMapping("/editBookMotorbikeAdminUser/{id}")
    public ModelAndView updateStatusBookBus(@PathVariable("id") Long id) {
        // Create a ModelAndView object for the "motorbike/editBookMotorbike" view
        ModelAndView mv = new ModelAndView("motorbike/editBookMotorbike");

        // Add the following objects as attributes to the ModelAndView:
        // 1. The motorbike service booking found by its ID
        mv.addObject("bookMotorbike", bookMotorbikeRepository.findById(id));
        // 2. Enum values for status services (assuming it's an Enum)
        mv.addObject("statusServices", StatusService.values());
        // 3. Enum values for type services (assuming it's an Enum)
        mv.addObject("typeServices", TypeService.values());
        // 4. List of mechanics (likely retrieved from a repository)
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView, which will be used to render the view
        return mv;
    }

    // Handler for GET request to list booked motorbike services
    @GetMapping("/listMotorbikeBooked")
    public ModelAndView listMotorbikeBooked() {
        // Create a ModelAndView object and specify the view template
        ModelAndView mv = new ModelAndView("/motorbike/listMotorbikeBooked");

        // Retrieve a list of booked motorbike services from the repository
        // and add it to the ModelAndView as an attribute named "bookMotorbikes"
        mv.addObject("bookMotorbikes", bookMotorbikeRepository.findAll());

        // Return the ModelAndView object, which indicates the view to render
        return mv;
    }

    // Handler for GET request to delete a booked motorbike service by ID
    @GetMapping("/deleteBookMotorbike/{id}")
    public RedirectView deleteBookMotorbike(@PathVariable("id") Long id) {
        // Delete the motorbike service from the repository using the provided ID
        bookMotorbikeRepository.deleteById(id);

        // Return a RedirectView to the home page ("/")
        return new RedirectView("/");
    }

    // Handler for GET request to generate and export an invoice for a booked motorbike service
    @GetMapping("/generateInvoiceBookMotorbike/{id}")
    public void exportToPDF(HttpServletResponse response, @PathVariable("id") Long id) throws DocumentException, IOException {
        // Set the response content type to indicate that the response will be a PDF
        response.setContentType("application/pdf");

        // Create a date formatter to include the current date and time in the filename
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        // Set the content disposition header to indicate the filename of the exported PDF
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=invoice" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);

        // Find the booked motorbike service by ID
        BookMotorbike bookMotorbike = bookMotorbikeRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Create an instance of the GenerateBookMotorbikeInvoicePDF exporter
        GenerateBookMotorbikeInvoicePDF exporter = new GenerateBookMotorbikeInvoicePDF(bookMotorbike);

        // Export the invoice as a PDF using the exporter
        exporter.export(response);
    }

}
