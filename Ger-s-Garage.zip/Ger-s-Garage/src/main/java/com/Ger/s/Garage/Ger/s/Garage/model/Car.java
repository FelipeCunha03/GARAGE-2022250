/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.CarMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.CarTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 *
 * @author felipecunha
 */// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_CAR") // Specifies the name of the database table
public class Car extends Vehicles {

    // Represents the number of doors of the car
    private Integer numberDoor;

    // Represents the capacity of passengers the car can carry
    private Integer capacityPassengers;

    // Represents the make (brand) of the car (Enum: CarMakes)
    @Enumerated(EnumType.STRING)
    private CarMakes carMake;

    // Represents the type of the car (Enum: CarTypes)
    @Enumerated(EnumType.STRING)
    private CarTypes carType;

    // Represents the associated client (owner) of the car
    @ManyToOne
    @JoinColumn(name = "client_id_fk") // Specifies the foreign key column
    private Client client;

    // Constructor for creating a new Car instance with specified attributes
    public Car(Integer numberOfDoor, Integer capacityPassengers, CarMakes carMake, CarTypes carType, Client client, Integer year, String color, String plate, EngineTypes engineType) {
        // Call the constructor of the superclass (Vehicles) to initialize common vehicle attributes
        super(year, color, plate, engineType);
        this.numberDoor = numberOfDoor;
        this.capacityPassengers = capacityPassengers;
        this.carMake = carMake;
        this.carType = carType;
        this.client = client;
    }

    // Default constructor for the Car class
    public Car() {
    }

    // Overrides the toString method to return the car type
    @Override
    public String toString() {
        return "" + carType;
    }
}

