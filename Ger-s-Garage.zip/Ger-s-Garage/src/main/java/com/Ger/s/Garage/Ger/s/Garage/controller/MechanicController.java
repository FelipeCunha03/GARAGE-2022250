/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.ListVehicle;
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Mechanic;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.Ger.s.Garage.Ger.s.Garage.util.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

/**
 *  * @author felipecunha Controller class for managing mechanic and related
 * functionalities. This controller is responsible for handling various
 * operations related to mechanics in a garage management system. It includes
 * methods for registering new mechanics, editing existing mechanics, deleting
 * mechanics, listing mechanics, and editing mechanic profiles.
 *
 *
 */
@Controller
@RequestMapping("/mechanic")
public class MechanicController {

    // Autowired repositories for accessing data
    @Autowired
    private MechanicRepository mechanicRepository;

    @GetMapping("/registerMechanic")
    public ModelAndView registerAdm(Mechanic mechanic) {
        // Create a ModelAndView instance with the view name "mechanic/registerMechanic"
        ModelAndView mv = new ModelAndView("mechanic/registerMechanic");

        // Add the "mechanic" object to the model, which is used to bind form data
        mv.addObject("mechanic", mechanic);

        // Add enum values to the model for dropdown selection in the registration form
        mv.addObject("profiles", Profile.values()); // Enum values for mechanic profiles
        mv.addObject("vehicleSpecialtys", ListVehicle.values()); // Enum values for vehicle specialties

        // Return the ModelAndView instance to render the registration form
        return mv;
    }

    @PostMapping("/registerMechanic")
    public RedirectView registerClient(@ModelAttribute Mechanic mechanic) {
        // Encode the mechanic's password using a utility method (PasswordUtil.encoder)
        String hashPassword = PasswordUtil.encoder(mechanic.getPassword());
        // Set the hashed password back to the mechanic object
        mechanic.setPassword(hashPassword);

        // Save the mechanic object to the mechanicRepository
        mechanicRepository.save(mechanic);

        // Print a message indicating that the mechanic is saved
        System.out.println("Salved : " + mechanic.getFirstName() + " " + mechanic.getLastName());

        // Redirect to the root URL ("/") after the registration is complete
        return new RedirectView("/");
    }

    @GetMapping("/editMechanic/{id}")
    public ModelAndView editMechanic(@PathVariable("id") Long id) {
        // Create a ModelAndView instance with the view name "mechanic/editMechanic"
        ModelAndView mv = new ModelAndView("mechanic/editMechanic");

        // Retrieve the mechanic with the specified ID from the mechanicRepository
        // and add it to the model with the key "mechanic"
        mv.addObject("mechanic", mechanicRepository.findById(id));

        // Return the ModelAndView instance
        return mv;
    }

    @PostMapping("/editMechanic")
    public RedirectView editMechanic(Mechanic mechanic) {
        // Create a ModelAndView instance with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Save the updated mechanic information to the mechanicRepository
        mechanicRepository.save(mechanic);

        // Return a RedirectView to the root URL ("/") after the edit is complete
        return new RedirectView("/");
    }

    @GetMapping("/deleteMechanic/{id}")
    public RedirectView deleteMechanic(@PathVariable("id") Long id) {
        // Delete the mechanic with the specified ID from the mechanicRepository
        mechanicRepository.deleteById(id);

        // Return a RedirectView to the root URL ("/") after the mechanic is deleted
        return new RedirectView("/");
    }

    @GetMapping("/listMechanic")
    public ModelAndView listMechanic() {
        // Create a ModelAndView instance with the view name "mechanic/listMechanic"
        ModelAndView mv = new ModelAndView("/mechanic/listMechanic");

        // Add the list of mechanics retrieved from the mechanicRepository to the model
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView instance to render the "listMechanic" view
        return mv;
    }

    @GetMapping("/editMechanicProfile")
    public ModelAndView editMechanicProfile(@RequestParam("id") Long id) {
        // Create a ModelAndView instance with the view name "mechanic/editMechanicProfile"
        ModelAndView mv = new ModelAndView("mechanic/editMechanicProfile");

        // Retrieve the mechanic with the specified ID from the mechanicRepository
        // and add it to the model with the key "mechanic"
        mv.addObject("mechanic", mechanicRepository.findById(id));

        // Return the ModelAndView instance to render the "editMechanicProfile" view
        return mv;
    }

    @PostMapping("/editMechanicProfile")
    public RedirectView editMechanicProfile(Mechanic mechanic) {
        // Create a ModelAndView instance with the view name "index" (not used in the redirection)
        ModelAndView mv = new ModelAndView("index");

        // Save the updated mechanic information to the mechanicRepository
        mechanicRepository.save(mechanic);

        // Return a RedirectView to the root URL ("/") after the edit is complete
        return new RedirectView("/");
    }

}
