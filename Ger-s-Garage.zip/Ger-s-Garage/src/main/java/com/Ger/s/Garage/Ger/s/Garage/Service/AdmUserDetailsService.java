/*
 * This class implements the UserDetailsService interface from Spring Security and is used to load details about an ADM user (administrator) from a repository for authentication and authorization purposes.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Custom implementation of UserDetailsService for loading ADM user details from a repository.
 */
@Service
public class AdmUserDetailsService implements UserDetailsService {

    @Autowired
    private AdmRepository admRepository;

    /*
     * This method is an override of the loadUserByUsername method from the interface.
     * It retrieves an Adm entity by email from the repository and returns an AdmDetailsImpl object.
     * If the user is not found, a UsernameNotFoundException is thrown.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Adm adm = admRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Create an AdmDetailsImpl object with the retrieved ADM entity
        return new AdmDetailsImpl(adm);
    }
}
