/*
 * This class generates a PDF invoice for a booked car, including header and data cells for client information and details about the booked car service.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.model.BookCar;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.awt.Color;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;

/**
 * Generates a PDF invoice for a booked car.
 */
public class GenerateBookCarInvoicePDF {

    private BookCar bookCar;

    // Constructor to set the BookCar instance
    public GenerateBookCarInvoicePDF(BookCar bookCar) {
        this.bookCar = bookCar;
    }

    /**
     * Writes the header cells for the given PdfPTable. Sets the font and cell
     * values for each header cell.
     *
     * @param table The PdfPTable to which the header cells will be added.
     */
    private void writeTableHeader(PdfPTable table) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);

        addHeaderCell(table, "Client", font);
        addHeaderCell(table, "Phone-Number", font);
        addHeaderCell(table, "Vehicle", font);
        addHeaderCell(table, "Details about the fix", font);
        addHeaderCell(table, "General Cost", font);
        addHeaderCell(table, "Extra cost", font);
        addHeaderCell(table, "Final cost", font);
    }

    /**
     * Adds a header cell to the given PdfPTable with the specified text and
     * font.
     *
     * @param table The PdfPTable to which the header cell will be added.
     * @param text The text content for the header cell.
     * @param font The font to be applied to the header cell.
     */
    private void addHeaderCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(Color.BLACK);
        cell.setPadding(5);
        table.addCell(cell);
    }

    /**
     * Writes data cells for the given PdfPTable based on the properties of the
     * booked car.
     *
     * @param table The PdfPTable to which the data cells will be added.
     */
    private void writeTableData(PdfPTable table) {
        table.addCell(bookCar.getClient().getFirstName());
        table.addCell(String.valueOf(bookCar.getClient().getPhoneNumber()));
        table.addCell(bookCar.getCar().getCarType().toString());
        table.addCell(bookCar.getCarServiceDetails());
        table.addCell(String.valueOf(bookCar.getGeneralCost()));
        table.addCell(String.valueOf(bookCar.getExtralCost()));
        table.addCell(String.valueOf(bookCar.getFinalCost()));
    }

    /**
     * Exports an invoice as a PDF document to the HttpServletResponse. This
     * method generates an invoice layout, including header and data cells, and
     * sends it as a PDF file to the response output stream.
     *
     * @param response The HttpServletResponse where the PDF document will be
     * sent.
     * @throws DocumentException If there is an issue with creating the PDF
     * document.
     * @throws IOException If there is an issue with the response output stream.
     */
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLACK);

        Paragraph p = new Paragraph("Invoice", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);

        document.add(p);

        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100f);
        table.setWidths(new float[]{1.5f, 2.0f, 2.0f, 4.0f, 1.5f, 1.5f, 1.5f});

        table.setSpacingBefore(10);

        writeTableHeader(table);
        writeTableData(table);

        document.add(table);

        document.close();

    }

}
