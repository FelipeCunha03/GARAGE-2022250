/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.MotorbikeMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.MotorbikeTypes;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Motorbike;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.MotorbikeRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 * motorbikeController, responsible for handling various operations related to buses in a garage application
 */
@Controller
@RequestMapping("/motorbike") // Base URL mapping for all motorbike-related operations
public class MotorbikeController {

    @Autowired
    MotorbikeRepository motorbikeRepository; // Autowired repository for accessing motorbike data

    @Autowired
    ClientRepository clientRepository; // Autowired repository for accessing client data

    // Handler for GET request to register a new motorbike
    @GetMapping("/RegisterMotorbike")
    public ModelAndView registerMotorbikeGet(Motorbike motorBike) {
        // Create a ModelAndView instance with the view name "motorbike/RegisterMotorbike"
        ModelAndView mv = new ModelAndView("motorbike/RegisterMotorbike");

        // Add enum values to the model for dropdown selection in the registration form
        // The following enums are assumed to exist: MotorbikeMakes, MotorbikeTypes, EngineTypes
        mv.addObject("motorbikeMakes", MotorbikeMakes.values()); // Enum values for motorbike makes
        mv.addObject("motorbikeTypes", MotorbikeTypes.values()); // Enum values for motorbike types
        mv.addObject("engineTypes", EngineTypes.values()); // Enum values for engine types

        return mv;
    }

    // Handler for POST request to register a new motorbike
    @PostMapping("/RegisterMotorbike")
    public RedirectView registerMotorbike(@ModelAttribute Motorbike motorbike, @RequestParam("id") Long id) {
        // Declare a Client variable
        Client client;

        // Retrieve the client from the clientRepository using the provided id
        // If the client is not found, throw a UsernameNotFoundException
        client = clientRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Set the retrieved client for the motorbike
        motorbike.setClient(client);

        // Save the motorbike object to the motorbikeRepository
        motorbikeRepository.save(motorbike);

        // Return a RedirectView to the root path "/"
        return new RedirectView("/");
    }

    // Handler for GET request to edit a specific motorbike
    @GetMapping("/editMotorbike/{id}")
    public ModelAndView editMotorbike(@PathVariable("id") Long id) {
        // Create a ModelAndView instance with the view name "motorbike/editMotorbike"
        ModelAndView mv = new ModelAndView("motorbike/editMotorbike");

        // Retrieve the motorbike with the specified id from the motorbikeRepository
        // and add it to the model with the key "motorbike"
        mv.addObject("motorbike", motorbikeRepository.findById(id));

        // Add the enum values of MotorbikeMakes, MotorbikeTypes, and EngineTypes to the model
        mv.addObject("motorbikeMakes", MotorbikeMakes.values());
        mv.addObject("motorbikeTypes", MotorbikeTypes.values());
        mv.addObject("engineTypes", EngineTypes.values());

        // Return the ModelAndView instance
        return mv;
    }

    // Handler for POST request to edit/update a motorbike
    @PostMapping("/editMotorbike")
    public RedirectView editVCar(Motorbike motorbike) {
        // Save the updated motorbike information to the motorbikeRepository
        motorbikeRepository.save(motorbike);

        // Return a RedirectView to the root URL ("/") after the edit is complete
        return new RedirectView("/");
    }

    // Handler for GET request to delete a motorbike
    @GetMapping("/deleteMotorbike/{id}")
    public RedirectView deleteAdm(@PathVariable("id") Long id) {
        // Delete the motorbike with the specified ID from the motorbikeRepository
        motorbikeRepository.deleteById(id);

        // Return a RedirectView to the root URL ("/") after the motorbike is deleted
        return new RedirectView("/");
    }

    // Handler for GET request to list motorbikes associated with a client
    @GetMapping("/listMotorbike")
    public ModelAndView listMotorbike(@RequestParam("id") Long id) {
        // Create a new ModelAndView object for the "listMotorbike" view
        ModelAndView mv = new ModelAndView("/motorbike/listMotorbike");

        // Retrieve the list of motorbikes associated with the client ID
        // using the motorbikeRepository's findByClientId method
        mv.addObject("motorbikes", motorbikeRepository.findByClientId(id));

        // Return the ModelAndView object to render the "listMotorbike" view
        return mv;
    }
}
