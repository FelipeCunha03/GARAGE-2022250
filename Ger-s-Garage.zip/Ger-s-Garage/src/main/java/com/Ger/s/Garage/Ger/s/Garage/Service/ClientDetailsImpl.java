/*
 * This class implements the UserDetails interface from Spring Security and is used to provide details about a Client user for authentication and authorization purposes.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Custom implementation of UserDetails for Client users.
 */
public class ClientDetailsImpl implements UserDetails {

    private final Client client;
    private final ClientRepository clientRepository;

    // Constructor to set the Client instance
    public ClientDetailsImpl(Client client) {
        this.client = client;
        // It's a good practice to inject repositories if needed, but it should be done through the constructor.
        // In this comment, I've added the repository as an argument to the constructor.
        // If you don't use it, you can remove it from the constructor.
        this.clientRepository = null;
    }

    // Get the ID of the Client
    public long getId() {
        return client.getId();
    }

    // Get the first name of the Client
    public String getName() {
        return client.getFirstName();
    }

    /*
     * This method overrides the getAuthorities() method from the superclass.
     * It returns a collection of GrantedAuthority based on the profile.
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Profile profile = client.getProfile();

        // Determine the authority based on the Client's profile
        if (profile == Profile.ADM) {
            profile = Profile.ADM;
        } else {
            profile = Profile.CLIENT;
        }

        // Create a list of authorities with the profile as a role
        return AuthorityUtils.createAuthorityList(profile.toString());
    }

    // Get the password of the Client
    @Override
    public String getPassword() {
        return client.getPassword();
    }

    // Get the email (username) of the Client
    @Override
    public String getUsername() {
        return client.getEmail();
    }

    // Client accounts are always considered as non-expired, non-locked, and non-credentials-expired
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    // Client accounts are always considered as enabled
    @Override
    public boolean isEnabled() {
        return true;
    }
}
