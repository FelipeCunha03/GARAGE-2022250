/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;


/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
// - @MappedSuperclass: Indicates that this class is not a JPA entity but provides shared attributes for its subclasses.
@Getter
@Setter
@MappedSuperclass
public abstract class User {

    // Represents the unique identifier for the user
    @Column(name = "id_user", unique = true)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    // Represents the first name of the user
    @Column(name = "first_name")
    private String firstName;

    // Represents the last name of the user
    @Column(name = "Last_name")
    private String lastName;

    // Represents the phone number of the user
    @Column(name = "phone_number")
    private long phoneNumber;

    // Represents the address of the user
    @Column(name = "address_user")
    private String address;

    // Represents the password of the user (unique)
    @Column(name = "user_password", unique = true)
    private String password;

    // Represents the email (username) of the user (unique)
    @Column(name = "user_name", unique = true)
    private String email;

    // Represents the profile of the user, specified as an enumerated type (e.g., admin, client)
    @Column(name = "profile_user")
    @Enumerated(EnumType.STRING)
    private Profile profile;

    // Constructor for creating a new User instance with specified attributes
    public User(String firstName, String lastName, long phoneNumber, String address, String password, String email, Profile profile) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.password = password;
        this.email = email;
        this.profile = profile;
    }

    // Default constructor for the User class
    public User() {
    }

    // Override the toString method to provide a custom string representation of the User
    @Override
    public String toString() {
        return firstName;
    }
}

