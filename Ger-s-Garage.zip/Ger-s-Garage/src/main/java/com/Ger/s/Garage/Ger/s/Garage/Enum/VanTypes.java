/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum VanTypes {

    //list of types of small van  from makes   FordTransitConnect
    FordTransitConnectCargoVan("FordTransitConnectCargoVan"),
    FordTransitConnectPassengerWagon("FordTransitConnectPassengerWagon"),
    FordTransitConnectXLVan("FordTransitConnectXLVan"),
    FordTransitConnectXLTVan("FordTransitConnectXLTVan"),
    FordTransitConnectXLPassengerWagon("FordTransitConnectXLPassengerWagon"),
    FordTransitConnectElectric("FordTransitConnectElectric"),
    //list of types of small van  from makes   VolkswagenCaddy
    VolkswagenCaddyCargoVan("VolkswagenCaddyCargoVan"),
    VolkswagenCaddyPassengerVan("VolkswagenCaddyPassengerVan"),
    VolkswagenCaddyMaxiCargoVan("VolkswagenCaddyMaxiCargoVan"),
    VolkswagenCaddyMaxiPassengerVan("VolkswagenCaddyMaxiPassengerVan"),
    VolkswagenCaddyLife("VolkswagenCaddyLife"),
    VolkswagenCaddyAlltrack("VolkswagenCaddyAlltrack"),
    VolkswagenCaddyCamper("VolkswagenCaddyCamper"),
    //list of types of small van  from makes   CitroënBerlingo
    CitroënBerlingoCargoVan("VolkswagenCaddyCargoVan"),
    CitroënBerlingoPassengerVan("VolkswagenCaddyPassengerVan"),
    CitroënBerlingoMultispace("VolkswagenCaddyMaxiCargoVan"),
    CitroënBerlingoWorker("VolkswagenCaddyMaxiPassengerVan"),
    CitroënBerlingoElectric("VolkswagenCaddyLife"),
    //list of types of small van  from makes   RenaultKangoo
    RenaultKangooCargoVan("RenaultKangooCargoVan"),
    RenaultKangooPassengerVan("RenaultKangooPassengerVan"),
    RenaultKangooZ("RenaultKangooZ"),
    RenaultKangooMaxiCargoVan("RenaultKangooMaxiCargoVan"),
    RenaultKangooMaxiPassengerVan("RenaultKangooMaxiPassengerVan"),
    //list of types of small van  from makes MercedesBenzCitan
    MercedesBenzCitanCargoVan("MercedesBenzCitanCargoVan"),
    MercedesBenzCitanTourer("MercedesBenzCitanTourer"),
    MercedesBenzCitanMixto("MercedesBenzCitanMixto"),
    MercedesBenzCitanPanelVan("MercedesBenzCitanPanelVan"),
    MercedesBenzCitanDualiner("MercedesBenzCitanDualiner"),
    //list of types of small van  from makesNissanNV200
    NissanNV200CargoVan("MercedesBenzCitanCargoVan"),
    NissanNV200Combi("MercedesBenzCitanTourer"),
    NissanNV200Evalia("MercedesBenzCitanMixto"),
    NissanNV200CompactCargo("MercedesBenzCitanPanelVan"),
    //list of types of small van  from makes  ToyotaProaceCity
    ToyotaProaceCityVan("ToyotaProaceCityVan"),
    ToyotaProaceCityVerso("ToyotaProaceCityVerso"),
    ToyotaProaceCityElectric("ToyotaProaceCityElectric");

    private String MotorbikesType;

    private VanTypes(String MotorbikesType) {
        this.MotorbikesType = MotorbikesType;
    }

    public String getMotorbikesType() {
        return MotorbikesType;
    }

    public void setMotorbikesType(String MotorbikesType) {
        this.MotorbikesType = MotorbikesType;
    }

}
