/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.Table;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_CLIENT") // Specifies the name of the database table
public class Client extends User {

    // Represents the list of vans associated with this client
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Van" entity
    private List<Van> van = new ArrayList();

    // Represents the list of buses associated with this client
    @OneToMany(mappedBy = "client", cascade = CascadeType.PERSIST) // Specifies the relationship with the "Bus" entity
    private List<Bus> bus = new ArrayList();

    // Represents the list of motorbikes associated with this client
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Motorbike" entity
    private List<Motorbike> motorbikes = new ArrayList();

    // Represents the list of cars associated with this client
    @OneToMany(mappedBy = "client") // Specifies the relationship with the "Car" entity
    private List<Car> car = new ArrayList();

    // Constructor for creating a new Client instance with specified attributes
    public Client(String firstName, String lastName, long phoneNumber, String address, String password, String email, Profile profile) {
        // Call the constructor of the superclass (User) to initialize user attributes
        super(firstName, lastName, phoneNumber, address, password, email, profile);
    }

    // Default constructor for the Client class
    public Client() {
    }

}
