package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Adm entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom method for finding an Adm entity by email.
 */
@Repository
public interface AdmRepository extends JpaRepository<Adm, Long> {

    /**
     * Find an Adm entity by email.
     * @param email the email to search for
     * @return an Optional containing the found Adm entity, or an empty Optional if not found
     */
    Optional<Adm> findByEmail(String email);
}
