/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

import lombok.Setter;

/**
 *
 * @author felipecunha
 */
public enum CarMakes {

    Volkswagen("Volkswagen"),
    Audi("Audi"),
    BMW("BMW"),
    MercedesBenz("Mercedes-Benz"),
    Volvo("Volvo"),
    Fiat("Fiat"),
    Renault("Renault"),
    Lamborghini("Lamborghini");

    private String carMakes;

    private CarMakes(String makesCar) {
        this.carMakes = makesCar;
    }

    public String getMakesCar() {
        return carMakes;
    }

    public void setMakesCar(String makesCar) {
        this.carMakes = makesCar;
    }

}
