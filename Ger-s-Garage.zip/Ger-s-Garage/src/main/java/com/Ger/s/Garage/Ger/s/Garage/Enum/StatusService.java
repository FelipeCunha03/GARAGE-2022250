/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum StatusService {

    Booked("Booked"),
    InService("InService"),
    Fixed("Fixed"),
    Collected("Collected"),
    Unrepairable("Unrepairable");

    private String statusService;

    private StatusService(String statusService) {
        this.statusService = statusService;
    }

    public String getStatusService() {
        return statusService;
    }

    public void setStatusService(String statusService) {
        this.statusService = statusService;
    }

    

}
