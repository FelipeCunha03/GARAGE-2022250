/*
 * This class implements the UserDetailsService interface from Spring Security and is used to load details about a Client user from a repository for authentication and authorization purposes.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * Custom implementation of UserDetailsService for loading Client user details from a repository.
 */
@Service
public class ClientUserDetailsService implements UserDetailsService {

    @Autowired
    private ClientRepository clientRepository;

    /*
     * This method is an override of the loadUserByUsername method from the interface.
     * It retrieves a Client entity by email from the repository and returns a ClientDetailsImpl object.
     * If the user is not found, a UsernameNotFoundException is thrown.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Client client = clientRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Create a ClientDetailsImpl object with the retrieved Client entity
        return new ClientDetailsImpl(client);
    }
}
