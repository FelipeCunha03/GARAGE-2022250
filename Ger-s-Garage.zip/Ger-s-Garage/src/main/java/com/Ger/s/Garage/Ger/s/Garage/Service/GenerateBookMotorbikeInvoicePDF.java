/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.model.BookCar;
import com.Ger.s.Garage.Ger.s.Garage.model.BookMotorbike;
import com.Ger.s.Garage.Ger.s.Garage.model.BookVan;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

/**
 *
 * @author felipecunha
 */
public class GenerateBookMotorbikeInvoicePDF {

    private BookMotorbike bookMotorbike;

    public GenerateBookMotorbikeInvoicePDF(BookMotorbike bookMotorbike) {
        this.bookMotorbike = bookMotorbike;
    }

    /**
     * Writes the header cells for a PdfPTable, specifying column names.
     *
     * @param table The PdfPTable to which the header cells will be added.
     */
    private void writeTableHeader(PdfPTable table) {
        // Create a font for the header cells (Helvetica with white text)
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);

        // Add header cells for each column with specified font
        addHeaderCell(table, "Client", font);
        addHeaderCell(table, "Phone-Number", font);
        addHeaderCell(table, "Vehicle", font);
        addHeaderCell(table, "Details about the fix", font);
        addHeaderCell(table, "General Cost", font);
        addHeaderCell(table, "Extra cost", font);
        addHeaderCell(table, "Final cost", font);
    }

    /**
     * Adds a header cell to a PdfPTable with the specified text and font.
     *
     * @param table The PdfPTable to which the header cell will be added.
     * @param text The text content to be displayed in the header cell.
     * @param font The Font to be applied to the text in the header cell.
     */
    private void addHeaderCell(PdfPTable table, String text, Font font) {
        // Create a new PdfPCell with the specified text and font
        PdfPCell cell = new PdfPCell(new Phrase(text, font));

        // Set the background color of the cell to black
        cell.setBackgroundColor(Color.BLACK);

        // Set the padding for the cell
        cell.setPadding(5);

        // Add the cell to the table
        table.addCell(cell);
    }

    /**
     * Writes the data related to a booked motorbike into a PdfPTable.
     *
     * @param table The PdfPTable to which the motorbike booking data will be
     * added.
     */
    private void writeTableData(PdfPTable table) {
        // Add the client's first name to the table
        table.addCell(bookMotorbike.getClient().getFirstName());

        // Add the client's phone number to the table
        table.addCell(String.valueOf(bookMotorbike.getClient().getPhoneNumber()));

        // Add the motorbike type to the table
        table.addCell(bookMotorbike.getMotorbike().getMotorbikeType().toString());

        // Add the motorbike service details to the table
        table.addCell(bookMotorbike.getMotorbikeServiceDetails());

        // Add the general cost to the table
        table.addCell(String.valueOf(bookMotorbike.getGeneralCost()));

        // Add the extra cost to the table
        table.addCell(String.valueOf(bookMotorbike.getExtralCost()));

        // Add the final cost to the table
        table.addCell(String.valueOf(bookMotorbike.getFinalCost()));
    }

    /**
     * Generates and exports an invoice in PDF format.
     *
     * @param response The HttpServletResponse to which the generated PDF will
     * be written.
     * @throws DocumentException If there is an error with the PDF document
     * generation.
     * @throws IOException If there is an IO error while writing the PDF to the
     * response.
     */
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        // Create a new document with A4 page size
        Document document = new Document(PageSize.A4);

        // Get the output stream from the response to write the PDF
        PdfWriter.getInstance(document, response.getOutputStream());

        // Open the document
        document.open();

        // Create a bold font for the invoice title
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLACK);

        // Create a paragraph for the invoice title and center align it
        Paragraph p = new Paragraph("Invoice", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);

        // Add the title to the document
        document.add(p);

        // Create a PdfPTable with 7 columns and set width percentages
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100f);
        table.setWidths(new float[]{1.5f, 2.0f, 2.0f, 4.0f, 1.5f, 1.5f, 1.5f});

        // Add spacing before the table
        table.setSpacingBefore(10);

        // Write the table header
        writeTableHeader(table);

        // Write the table data
        writeTableData(table);

        // Add the table to the document
        document.add(table);

        // Close the document
        document.close();
    }

}
