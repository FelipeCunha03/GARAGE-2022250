/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum TypesVechicle {

    CAR("CAR"),
    BUS("BUS"),
    MOTORBIKE("MOTORBIKE"),
    VAN("VAN");

    private String typesVechicle;

    private TypesVechicle(String typesVechicle) {
        this.typesVechicle = typesVechicle;
    }

    public String getTypesVechicle() {
        return typesVechicle;
    }

    public void setTypesVechicle(String typesVechicle) {
        this.typesVechicle = typesVechicle;
    }

}
