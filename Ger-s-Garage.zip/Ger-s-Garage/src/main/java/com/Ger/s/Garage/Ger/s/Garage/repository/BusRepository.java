package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Bus entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom query method for finding Bus entities by client ID.
 */
@Repository
public interface BusRepository extends JpaRepository<Bus, Long> {

    /**
     * Find a list of Bus entities by the ID of the associated client.
     * @param clientId the ID of the client
     * @return a list of Bus entities associated with the given client ID
     */
    @Query("select b from Bus b where b.client.id = :clientId")
    List<Bus> findByClientId(Long clientId);
}
