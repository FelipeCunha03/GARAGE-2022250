/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum EngineTypes {

    DIESEL("DIESEL"),
    PETROL("PETROL"),
    HYBRID("HYBRID"),
    ELETRIC("ELETRIC");

    private String engineType;

    private EngineTypes(String EngineType) {
        this.engineType = EngineType;
    }

    public String getEngineType() {
        return engineType;
    }

    public void setEngineType(String EngineType) {
        this.engineType = EngineType;
    }

}
