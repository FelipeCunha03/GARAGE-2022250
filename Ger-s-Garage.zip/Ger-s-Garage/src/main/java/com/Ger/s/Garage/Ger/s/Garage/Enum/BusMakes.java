/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum BusMakes {

    FordTransitMinibus("FordTransitMinibus"),
    RenaultMasterMinibus("RenaultMasterMinibus"),
    MercedesBenzSprinterMinibus("MercedesBenzSprinterMinibus"),
    VolkswagenCrafterMinibus("VolkswagenCrafterMinibus"),
    FiatDucatoMinibus("FiatDucatoMinibus"),
    PeugeotBoxerMinibus("PeugeotBoxerMinibus"),
    OpelMovanoMinibus("OpelMovanoMinibus");

    private String busMakes;

    private BusMakes(String busMakes) {
        this.busMakes = busMakes;
    }

    public String getBusMakes() {
        return busMakes;
    }

    public void setBusMakes(String busMakes) {
        this.busMakes = busMakes;
    }

}
