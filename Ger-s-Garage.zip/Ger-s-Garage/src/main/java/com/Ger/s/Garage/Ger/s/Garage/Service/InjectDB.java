/*
 * This class is responsible for injecting initial data into the database.
 * It creates instances of different user profiles (Client, ADM, Mechanic) and saves them in the respective repositories.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import com.Ger.s.Garage.Ger.s.Garage.Enum.ListVehicle;
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.model.Mechanic;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.Ger.s.Garage.Ger.s.Garage.util.PasswordUtil;

import java.util.Arrays;
import org.springframework.stereotype.Service;

/**
 * This service class is responsible for injecting initial data into the
 * database. It creates instances of different user profiles (Client, ADM,
 * Mechanic) and saves them in the respective repositories. The initial data
 * includes client, ADM, and mechanic profiles.
 */
@Service
public class InjectDB {

  

  

    // Initial data for an ADM
    String firstNameADM = "Bianca";
    String lastNameADM = "Cunha";
    long phoneNumberADM = 830789393;
    String addressADM = "19 Ghatam Place";
    String passwordADM = PasswordUtil.encoder("Positivo10");
    String emailADM = "Bianca.Cunha03@hotmail.com";
    Profile profileADM = Profile.ADM;

    // Initial data for a Mechanic
    String firstNameMechanic = "Carla";
    String lastNameMechanic = "Cunha";
    long phoneNumberMechanic = 830789393;
    String addressMechanic = "19 Ghatam Place";
    String passwordMechanic = PasswordUtil.encoder("Positivo11");
    String emailMechanic = "Carla.Cunha03@hotmail.com";
    Profile profileMechanic = Profile.MECHANIC;
    ListVehicle listVehicle = ListVehicle.BUS;
    String PPSNO = "2022208TA";

    // Autowired repositories for data access
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private AdmRepository admRepository;

    @Autowired
    private MechanicRepository mechanicRepository;

    /**
     * Injects the initial data into the database by creating instances of
     * different user profiles (Client, ADM, Mechanic) and saving them in the
     * respective repositories.
     */
    public void injectDB() {
        // Create and save clients
    

        // Create and save ADM
        Adm adm1 = new Adm(firstNameADM, lastNameADM, phoneNumberADM, addressADM, passwordADM, emailADM, profileADM);
        admRepository.saveAll(Arrays.asList(adm1));

        // Create and save mechanic
        Mechanic mechanic1 = new Mechanic(PPSNO, firstNameMechanic, lastNameMechanic, phoneNumberMechanic, addressMechanic, passwordMechanic, emailMechanic, profileMechanic);
        mechanicRepository.saveAll(Arrays.asList(mechanic1));
    }
}
