// Package declaration
package com.Ger.s.Garage.Ger.s.Garage.controller;

// Import statements
import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Adm;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.VanRepository;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller class for managing administrators (adms) and related
 * functionalities.
 */
@Controller
@RequestMapping("/adm")
public class AdmController {

    // Autowired repositories for accessing data
    @Autowired
    private AdmRepository admRepository;

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private VanRepository vanRepository;

    @Autowired
    private MotorbikeRepository motorbikeRepository;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MechanicRepository mechanicRepository;

    /**
     * Handler for GET request to display the registration form for an admin
     * (Adm) user.
     *
     * @param adm An empty or default Adm object (can be pre-populated with
     * default values).
     * @return A ModelAndView object for rendering the "registerAdm" view.
     */
    @GetMapping("/registerAdm")
    public ModelAndView registerAdmGet(Adm adm) {
        // Create a ModelAndView object for rendering the registration form
        ModelAndView mv = new ModelAndView("adm/registerAdm");
        // Add the empty or default Adm object to the view
        mv.addObject("adm", adm);
        // Add the available profiles (e.g., roles) to the view for user selection
        mv.addObject("profiles", Profile.values());
        // Return the ModelAndView object to display the registration form
        return mv;
    }

    /**
     * Handler for POST request to register a new administrator (Adm) user.
     *
     * @param adm The Adm object containing the details of the new
     * administrator.
     * @return A RedirectView to the home page after the new administrator is
     * saved.
     */
    @PostMapping("/registerAdm")
    public RedirectView registerAdm(@ModelAttribute Adm adm) {
        // Save the new administrator in the repository
        admRepository.save(adm);
        // Redirect to the home page
        return new RedirectView("/");
    }

    /**
     * Handler for GET request to list users, including clients, administrators,
     * and mechanics.
     *
     * @return A ModelAndView object representing the view "listUsers",
     * populated with lists of clients, administrators, and mechanics.
     */
    @GetMapping("/listUsers")
    public ModelAndView listUsers() {
        // Create a ModelAndView object for the "listUsers" view
        ModelAndView mv = new ModelAndView("/adm/listUsers");

        // Retrieve and add lists of clients, administrators, and mechanics to the ModelAndView
        mv.addObject("clients", clientRepository.findAll()); // Retrieve all clients from the client repository
        mv.addObject("adms", admRepository.findAll()); // Retrieve all administrators from the adm repository
        mv.addObject("mechanics", mechanicRepository.findAll()); // Retrieve all mechanics from the mechanic repository

        // Return the ModelAndView object populated with user lists for display in the "listUsers" view
        return mv;
    }

    /**
     * Handler for GET request to list vehicles, including buses, cars, vans,
     * and motorbikes.
     *
     * @return A ModelAndView object representing the view "listVechicle",
     * populated with lists of buses, cars, vans, and motorbikes.
     */
    @GetMapping("/listVechicle")
    public ModelAndView listVechicle() {
        // Create a ModelAndView object for the "listVechicle" view
        ModelAndView mv = new ModelAndView("/listVechicle");

        // Retrieve and add lists of buses, cars, vans, and motorbikes to the ModelAndView
        mv.addObject("buses", busRepository.findAll()); // Retrieve all buses from the bus repository
        mv.addObject("cars", carRepository.findAll()); // Retrieve all cars from the car repository
        mv.addObject("vans", vanRepository.findAll()); // Retrieve all vans from the van repository
        mv.addObject("motorbikes", motorbikeRepository.findAll()); // Retrieve all motorbikes from the motorbike repository

        // Return the ModelAndView object populated with lists of vehicles for display in the "listVechicle" view
        return mv;
    }

    /**
     * Handler for GET request to edit an administrator by ID.
     *
     * @param id The ID of the administrator to be edited.
     * @return A ModelAndView object representing the view "adm/editAdm",
     * populated with the administrator object to be edited.
     */
    @GetMapping("/editAdm/{id}")
    public ModelAndView editAdm(@PathVariable("id") Long id) {
        // Create a ModelAndView object for the "adm/editAdm" view
        ModelAndView mv = new ModelAndView("adm/editAdm");

        // Retrieve the administrator object by ID from the admRepository
        // and add it as an attribute to the ModelAndView
        mv.addObject("adm", admRepository.findById(id));

        // Return the ModelAndView object populated with the administrator object
        // to be edited in the "adm/editAdm" view
        return mv;
    }

    // Handler for POST request to edit an administrator
    @PostMapping("/editAdm")
    public RedirectView editAdm(Adm adm) {
        // Save the edited administrator in the repository
        admRepository.save(adm);
        return new RedirectView("/");
    }

    /**
     * Handler for GET request to delete an administrator by ID.
     *
     * @param id The ID of the administrator to be deleted.
     * @return A RedirectView to the root URL ("/") after the administrator is
     * deleted.
     */
    @GetMapping("/deleteAdm/{id}")
    public RedirectView deleteAdm(@PathVariable("id") Long id) {
        // Delete the administrator from the admRepository by ID
        admRepository.deleteById(id);

        // Redirect to the root URL ("/") after the deletion is completed
        return new RedirectView("/");
    }

    /**
     * Handler for GET request to list administrators.
     *
     * @return A ModelAndView containing the list of administrators and the view
     * to render.
     */
    @GetMapping("/listAdm")
    public ModelAndView listAdms() {
        // Create a new ModelAndView with the view "adm/listAdm"
        ModelAndView mv = new ModelAndView("/adm/listAdm");

        // Add the list of administrators to the ModelAndView
        mv.addObject("adms", admRepository.findAll());

        // Return the ModelAndView, which will render the "adm/listAdm" view with the list of administrators
        return mv;
    }

    /**
     * Handler for GET request to edit the profile of an administrator.
     *
     * @param id The ID of the administrator to edit.
     * @return A ModelAndView containing the administrator object and the view
     * to render.
     */
    @GetMapping("/editAdmProfile")
    public ModelAndView editAdmProfile(@RequestParam("id") Long id) {
        // Create a new ModelAndView with the view "adm/editAdmProfile"
        ModelAndView mv = new ModelAndView("adm/editAdmProfile");

        // Retrieve the administrator object from the repository based on the provided ID
        // and add it to the ModelAndView
        mv.addObject("adm", admRepository.findById(id));

        // Return the ModelAndView, which will render the "adm/editAdmProfile" view with the administrator's profile
        return mv;
    }

    /**
     * Handler for POST request to edit the profile of an administrator.
     *
     * @param adm The edited Adm object containing the updated profile
     * information.
     * @return A RedirectView to the home page ("/") after saving the changes.
     */
    @PostMapping("/editAdmProfile")
    public RedirectView editAdmProfile(Adm adm) {
        // Save the edited profile of the administrator in the repository
        admRepository.save(adm);

        // Return a RedirectView to the home page ("/") after saving the changes
        return new RedirectView("/");
    }

}
