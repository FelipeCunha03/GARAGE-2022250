/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author felipecunha This controller is straightforward. It provides a single
 * GET endpoint at the "/login" URL, which returns the view name "login/login."
 * This endpoint is typically used for rendering the login page, allowing users
 * to log into the application. The "login/login" view is expected to be
 * resolved by the ViewResolver configured in the Spring application. The view
 * resolver will determine the appropriate view template to render based on the
 * view name.
 *
 */
@Controller
public class UserController {

    // Handler for GET request to the "/login" URL
    @GetMapping("/login")
    public String login() {
        // This method is responsible for returning the view name "login/login"
        return "login/login";
    }

}
