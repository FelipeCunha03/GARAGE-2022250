package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.model.BookMotorbike;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing BookMotorbike entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines custom query methods for finding BookMotorbike entities based on various criteria.
 */
@Repository
public interface BookMotorbikeRepository extends JpaRepository<BookMotorbike, Long> {

    /**
     * Find a list of BookMotorbike entities by the ID of the associated client.
     * @param clientId the ID of the client
     * @return a list of BookMotorbike entities associated with the given client ID
     */
    @Query("select b from BookMotorbike b where b.client.id = :clientId")
    List<BookMotorbike> findBookMotorbikeByClient(Long clientId);

    /**
     * Find a list of BookMotorbike entities by the ID of the associated mechanic.
     * @param mechanicId the ID of the mechanic
     * @return a list of BookMotorbike entities associated with the given mechanic ID
     */
    @Query("select b from BookMotorbike b where b.mechanic.id = :mechanicId")
    List<BookMotorbike> findBookMotorbikeByMechanic(Long mechanicId);

    /**
     * Count the number of BookMotorbike entities with a specific status and date of service.
     * @param statusService the status of the service
     * @param dateService the date of the service
     * @return the count of BookMotorbike entities with the specified status and date of service
     */
    @Query("select count(b) from BookMotorbike b where b.statusService = :statusService and b.dateService = :dateService")
    Long findBookMotorbikeByday(StatusService statusService, Date dateService);
}
