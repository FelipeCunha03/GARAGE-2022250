// Package declaration
package com.Ger.s.Garage.Ger.s.Garage.config;

// Import statements
import com.Ger.s.Garage.Ger.s.Garage.Service.AdmUserDetailsService;
import com.Ger.s.Garage.Ger.s.Garage.Service.ClientUserDetailsService;
import com.Ger.s.Garage.Ger.s.Garage.Service.MechanicUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * Configuration class for Spring Security and web-related security settings.
 * Extends WebSecurityConfigurerAdapter for custom security configuration.
 */
@Configuration
@EnableWebSecurity
public class WebConfigProject extends WebSecurityConfigurerAdapter {

    @Autowired
    private ClientUserDetailsService clientUserDetailsService;

    @Autowired
    private AdmUserDetailsService admUserDetailsService;

    @Autowired
    private MechanicUserDetailsService mechanicUserDetailsService;

    // Configure HTTP security settings
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // Specify URL permissions
        http.authorizeRequests()
                .antMatchers("/client/registerClient/**").permitAll()
                .antMatchers("/images/**").permitAll()
                .antMatchers("/css/**").permitAll()
                .antMatchers("/js/**").permitAll()
                .antMatchers("/fonts/**").permitAll()
                .antMatchers("/vendors/**").permitAll()
                .anyRequest().authenticated(); // Any request not on the list requires authentication

        // Configure form-based login
        http.formLogin()
                .loginPage("/login") // Custom login page URL
                .defaultSuccessUrl("/") // Default success URL after login
                .permitAll();

        // Configure logout
        http.logout()
                .logoutRequestMatcher(
                        new AntPathRequestMatcher("/logout", "GET")
                )
                .logoutSuccessUrl("/login"); // Redirect to the login page after logout
    }

    // Configure authentication providers
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        // Configure user details service and password encoder for clients
        auth.userDetailsService(clientUserDetailsService)
                .passwordEncoder(new BCryptPasswordEncoder());

        // Configure user details service and password encoder for administrators
        auth.userDetailsService(admUserDetailsService)
                .passwordEncoder(new BCryptPasswordEncoder());

        // Configure user details service and password encoder for mechanics
        auth.userDetailsService(mechanicUserDetailsService)
                .passwordEncoder(new BCryptPasswordEncoder());
    }
}
