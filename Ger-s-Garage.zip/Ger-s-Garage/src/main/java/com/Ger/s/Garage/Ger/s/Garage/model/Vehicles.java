/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
// - @MappedSuperclass: Specifies that this class is a mapped superclass, meaning it is not a complete entity itself but provides common attributes for its subclasses.
@Getter
@Setter
@MappedSuperclass
public abstract class Vehicles {

    // Represents the unique identifier for the vehicle
    @Column
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    // Represents the year of manufacture of the vehicle
    @Column
    private Integer year;

    // Represents the color of the vehicle
    @Column
    private String color;

    // Represents the license plate number of the vehicle
    @Column
    private String plate;

    // Represents the type of engine used in the vehicle (e.g., Diesel, Petrol)
    @Enumerated(EnumType.STRING)
    private EngineTypes engineType;

    // Constructor for creating a new Vehicles instance with specified attributes
    public Vehicles(Integer year, String color, String plate, EngineTypes engineType) {
        this.year = year;
        this.color = color;
        this.plate = plate;
        this.engineType = engineType;
    }

    // Default constructor for the Vehicles class
    public Vehicles() {
    }
}
