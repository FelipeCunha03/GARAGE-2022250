/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum BusTypes {

    // types from bus the makes FordTransitMinibus
    FordTransit12SeaterMinibus("FordTransit12SeaterMinibus"),
    FordTransit15SeaterMinibus("FordTransit15SeaterMinibus"),
    FordTransitWheelchairAccessibleMinibus("FordTransitWheelchairAccessibleMinibus"),
    FordTransitExecutiveMinibus("FordTransitWheelchairAccessibleMinibus"),
    FordTransitSchoolMinibus("FordTransitSchoolMinibus"),
    FordTransitConversionMinibus("FordTransitConversionMinibus"),
    // Types of bus  from the make RenaultMasterMinibus  

    RenaultMaster9SeaterMinibus("RenaultMaster9SeaterMinibus"),
    RenaultMaster12SeaterMinibus("RenaultMaster12SeaterMinibus"),
    RenaultMasterWheelchairAccessibleMinibus("RenaultMasterWheelchairAccessibleMinibus"),
    RenaultMasterSchoolBus("RenaultMasterTipper"),
    RenaultMasterExecutiveMinibus("RenaultMasterExecutiveMinibus"),
    RenaultMasterConversionMinibus("RenaultMasterConversionMinibus"),
    // Types of bus  from the make MercedesBenzSprinterMinibus 

    MercedesBenzSprinter12SeaterMinibus("MercedesBenzSprinter12SeaterMinibus"),
    MercedesBenzSprinter15SeaterMinibus("MercedesBenzSprinter15SeaterMinibus"),
    MercedesBenzSprinterExecutiveMinibus("MercedesBenzSprinterExecutiveMinibus"),
    MercedesBenzSprinterWheelchairAccessibleMinibus("MercedesBenzSprinterWheelchairAccessibleMinibus"),
    MercedesBenzSprinterSchoolMinibus("MercedesBenzSprinterSchoolMinibus"),
    // Types of bus  from the makes  VolkswagenCrafterMinibus

    VolkswagenCrafterPassenger("VolkswagenCrafterPassenger"),
    VolkswagenCrafterShuttleBus("VolkswagenCrafterShuttleBus"),
    VolkswagenCrafterWheelchairAccessibleMinibus("VolkswagenCrafterWheelchairAccessibleMinibus"),
    // Types of bus  from the makes  FiatDucatoMinibus

    FiatDucato9SeaterMinibus("FiatDucato9SeaterMinibus"),
    FiatDucato12SeaterMinibus("FiatDucato12SeaterMinibus"),
    FiatDucatoWheelchairAccessibleMinibus("FiatDucatoWheelchairAccessibleMinibus"),
    FiatDucatoSchoolBus("FiatDucatoSchoolBus"),
    FiatDucatoExecutiveMinibus("FiatDucatoExecutiveMinibus"),
    FiatDucatoConversionMinibus("FiatDucatoConversionMinibus"),
    // Types of bus  from the makes PeugeotBoxerMinibus

    PeugeotBoxer9SeaterMinibus("PeugeotBoxer9SeaterMinibus"),
    PeugeotBoxer12SeaterMinibus("PeugeotBoxer12SeaterMinibus"),
    PeugeotBoxerWheelchairAccessibleMinibus("PeugeotBoxerWheelchairAccessibleMinibus"),
    PeugeotBoxerSchoolBus("PeugeotBoxerSchoolBus"),
    PeugeotBoxerExecutiveMinibus("PeugeotBoxerExecutiveMinibus"),
    PeugeotBoxerConversionMinibus("PeugeotBoxerConversionMinibus"),
    // list Types of bus  from the makes OpelMovanoMinibus

    OpelMovano9SeaterMinibus("OpelMovano9SeaterMinibus"),
    OpelMovano12SeaterMinibus("OpelMovano12SeaterMinibus"),
    OpelMovanoWheelchairAccessibleMinibus("OpelMovanoWheelchairAccessibleMinibus"),
    OpelMovanoSchoolBus("OpelMovanoSchoolBus"),
    OpelMovanoExecutiveMinibus("OpelMovanoExecutiveMinibus"),
    OpelMovanoConversionMinibus("OpelMovanoConversionMinibus");

    private String busType;

    private BusTypes(String busTypes) {
        this.busType = busTypes;
    }

    public String getBusTypes() {
        return busType;
    }

    public void setBusTypes(String busTypes) {
        this.busType = busTypes;
    }

}
