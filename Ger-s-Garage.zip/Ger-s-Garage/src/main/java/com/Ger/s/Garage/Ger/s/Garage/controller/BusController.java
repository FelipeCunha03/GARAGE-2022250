/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Service.ClientDetailsImpl;
import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 * BusController, responsible for handling various operations related to buses in a garage application
 */
@Controller
@RequestMapping("/bus") // Base URL mapping for all bus-related operations
public class BusController {

     // Autowired repositories for accessing data
    @Autowired
    BusRepository busRepository;

    @Autowired
    ClientRepository clientRepository;

    ClientDetailsImpl clientDetailsImpl;

    // Handler for GET request to register a new bus
    @GetMapping("/RegisterBus")
    public ModelAndView registerBus(Bus bus) {
        // Create a ModelAndView instance with the specified view name "bus/RegisterBus"
        ModelAndView mv = new ModelAndView("bus/RegisterBus");

        // Add the "bus" object to the model, which is used to bind form data
        mv.addObject("bus", bus);

        // Add enum values to the model for dropdown selection in the registration form
        // The following enums are assumed to exist: BusMakes, BusTypes, EngineTypes
        mv.addObject("busMakes", BusMakes.values()); // Enum values for bus makes
        mv.addObject("busTypes", BusTypes.values()); // Enum values for bus types
        mv.addObject("engineTypes", EngineTypes.values()); // Enum values for engine types

        return mv;
    }

    // Handler for POST request to register a new bus
    @PostMapping("/RegisterBus")
    public RedirectView registerBus(@ModelAttribute Bus bus, @RequestParam("id") Long id) {
        // Declare a Client variable
        Client client;

        // Retrieve the client from the clientRepository using the provided id
        // If the client is not found, throw a UsernameNotFoundException
        client = clientRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Set the retrieved client for the bus
        bus.setClient(client);

        // Create a ModelAndView instance with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Add the "Bus" object to the model
        mv.addObject("Bus", bus);

        // Save the bus object to the busRepository
        busRepository.save(bus);

        // Return a RedirectView to the root path "/"
        return new RedirectView("/");
    }

    // Handler for GET request to edit a specific bus
    @GetMapping("/editBus/{id}")
    public ModelAndView editBusGet(@PathVariable("id") Long id) {
        // Create a ModelAndView instance with the view name "bus/editBus"
        ModelAndView mv = new ModelAndView("bus/editBus");

        // Retrieve the bus with the specified id from the busRepository
        // and add it to the model with the key "bus"
        mv.addObject("bus", busRepository.findById(id));

        // Add the enum values of BusMakes, BusTypes, and EngineTypes to the model
        mv.addObject("busMakes", BusMakes.values());
        mv.addObject("busTypes", BusTypes.values());
        mv.addObject("engineTypes", EngineTypes.values());

        // Return the ModelAndView instance
        return mv;
    }

    // Handler for POST request to edit/update a bus
    @PostMapping("/editBus")
    public RedirectView editBus(Bus bus) {
        // Save the updated bus information to the busRepository
        busRepository.save(bus);

        // Return a RedirectView to the root URL ("/") after the edit is complete
        return new RedirectView("/");
    }

    // Handler for GET request to delete a bus
    @GetMapping("/deleteBus/{id}")
    public RedirectView deleteBus(@PathVariable("id") Long id) {
        // Delete the bus with the specified ID from the busRepository
        busRepository.deleteById(id);

        // Return a RedirectView to the root URL ("/") after the bus is deleted
        return new RedirectView("/");
    }

    // Handler for GET request to list buses associated with a client
    @GetMapping("/listBus")
    public ModelAndView listBus(@RequestParam("id") Long id) {
        // Create a new ModelAndView object for the "listBus" view
        ModelAndView mv = new ModelAndView("/bus/listBus");

        // Retrieve the list of buses associated with the client ID
        // using the busRepository's findByClientId method
        mv.addObject("buses", busRepository.findByClientId(id));

        // Return the ModelAndView object to render the "listBus" view
        return mv;
    }

}
