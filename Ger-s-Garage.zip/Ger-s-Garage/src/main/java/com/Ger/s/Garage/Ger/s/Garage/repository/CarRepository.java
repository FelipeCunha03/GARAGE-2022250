package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Car;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Car entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom query method for finding Car entities by client ID.
 */
@Repository
public interface CarRepository extends JpaRepository<Car, Long> {

    /**
     * Find a list of Car entities by the ID of the associated client.
     * @param clientId the ID of the client
     * @return a list of Car entities associated with the given client ID
     */
    @Query("select c from Car c where c.client.id = :clientId")
    List<Car> findByClientId(Long clientId);
}
