// Package declaration
package com.Ger.s.Garage.Ger.s.Garage.config;

// Import statements
import com.Ger.s.Garage.Ger.s.Garage.Service.InjectDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// Configuration class definition
@Configuration
public class InjectDBConfig {

    // Autowire the InjectDB service
    @Autowired
    private InjectDB injectDB;

    // Inject the value of the "spring.jpa.hibernate.ddl-auto" property
    // from application properties
    @Value("${spring.jpa.hibernate.ddl-auto}")
    private String value;

    // Bean definition
    @Bean
    // Method to conditionally inject database data
    public boolean injectDbinfos(){
        // Check if the value of "spring.jpa.hibernate.ddl-auto" is "create"
        if(value.equals("create")){
            // If the value is "create", invoke the injectDB method of the InjectDB service
            this.injectDB.injectDB();
        }
        // Return false to indicate that the bean creation is not successful
        // (This behavior is not entirely clear from the provided code)
        return false;
    }
}
