/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.Profile;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.AdmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import javax.persistence.EntityNotFoundException;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 * 
 * /**
 * Controller class for managing clients  and related
 * functionalities.
 * 
 * This controller is responsible for handling various operations related to client 
 * in a garage management system. It includes methods for registering new client, 
 * editing existing client, deleting client, listing client, and editing client profiles.
 */
 
@Controller
@RequestMapping("/client")
public class ClientController {

     // Autowired repositories for accessing data
    @Autowired
    ClientRepository clientRepository;

    @Autowired
    private AdmRepository admRepository;

    // Handler for GET request to display the client registration form
    @GetMapping("/registerClient")
    public ModelAndView registerClientGet(Client client) {
        // Create a ModelAndView object with the view name "client/registerClient"
        ModelAndView mv = new ModelAndView("client/registerClient");

        // Add a new Client object as a model attribute named "client"
        mv.addObject("client", new Client());

        // Add the list of Profile values (enums) as a model attribute named "profiles"
        mv.addObject("profiles", Profile.values());

        // Return the ModelAndView object
        return mv;
    }

    // Handler for POST request to register a client
    @PostMapping("/registerClient")
    public RedirectView registerClient(@ModelAttribute Client client) {
        // Create a ModelAndView object with the view name "login/login"
        ModelAndView mv = new ModelAndView("login/login");

        // Add the Client object as a model attribute named "client"
        mv.addObject("client", client);

        // Save the client object to the client repository (presumably a database)
        clientRepository.save(client);

        // Print a message to the console indicating the successful registration of the client
        System.out.println("Saved: " + client.getFirstName() + " " + client.getLastName());

        // Return a RedirectView to the root URL ("/")
        return new RedirectView("/");
    }

    // Handler for GET request to edit a client's information
    @GetMapping("/editClient/{id}")
    public ModelAndView editClient(@PathVariable("id") Long id) {
        // Create a ModelAndView object with the view name "client/editClient"
        ModelAndView mv = new ModelAndView("client/editClient");

        // Retrieve the client by its ID from the client repository
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Client not found"));

        // Add the retrieved client object as a model attribute named "client"
        mv.addObject("client", client);

        // Return the ModelAndView object
        return mv;
    }

    // Handler for POST request to edit/update a client's information
    @PostMapping("/editClient")
    public RedirectView editClient(Client client) {
        // Create a ModelAndView object with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Save the updated client information to the client repository
        clientRepository.save(client);

        // Return a RedirectView that redirects to the root ("/") URL
        return new RedirectView("/");
    }

    // Handler for GET request to delete a client
    @GetMapping("/deleteClient/{id}")
    public RedirectView deleteCliente(@PathVariable("id") Long id) {
        // Create a ModelAndView object with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Delete the client with the specified ID from the client repository
        clientRepository.deleteById(id);

        // Return a RedirectView that redirects to the root ("/") URL
        return new RedirectView("/");
    }

    // Handler for GET request to list all clients
    @GetMapping("/listClient")
    public ModelAndView listUsers() {
        // Create a ModelAndView object with the view name "/client/listClient"
        ModelAndView mv = new ModelAndView("/client/listClient");

        // Retrieve and add the list of all clients from the client repository to the ModelAndView
        mv.addObject("clients", clientRepository.findAll());

        // Return the ModelAndView object containing the list of clients and the view name
        return mv;
    }

    // Handler for GET request to edit client's profile
    @GetMapping("/editClientProfile")
    public ModelAndView editProfileClient(@RequestParam("id") Long id) {
        // Create a ModelAndView object with the view name "/client/editClientProfile"
        ModelAndView mv = new ModelAndView("/client/editClientProfile");

        // Retrieve the client with the specified ID from the client repository
        // and add it to the ModelAndView
        mv.addObject("client", clientRepository.findById(id));

        // Return the ModelAndView object containing the client's profile data and the view name
        return mv;
    }

    // Handler for POST request to update client's profile
    @PostMapping("/editClientProfile")
    public RedirectView editClientProfile(Client client) {
        // Save the updated client profile data to the client repository (database)
        clientRepository.save(client);

        // Redirect the user to the root ("/") URL after the profile is updated
        return new RedirectView("/");
    }

}
