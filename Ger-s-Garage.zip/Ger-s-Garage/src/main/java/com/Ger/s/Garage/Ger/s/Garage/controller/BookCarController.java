/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import com.Ger.s.Garage.Ger.s.Garage.Service.GenerateBookCarInvoicePDF;
import com.Ger.s.Garage.Ger.s.Garage.Service.BookServiceImp;
import com.Ger.s.Garage.Ger.s.Garage.model.BookBus;
import com.Ger.s.Garage.Ger.s.Garage.model.BookCar;
import com.Ger.s.Garage.Ger.s.Garage.model.Bus;
import com.Ger.s.Garage.Ger.s.Garage.model.Car;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookBusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestParam;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookCarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookMotorbikeRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BookVanRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.BusRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.MechanicRepository;
import com.lowagie.text.DocumentException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 */
@Controller
@RequestMapping("/car")
public class BookCarController {

    BookServiceImp bookServiceImp = new BookServiceImp();

    @Autowired
    private BookCarRepository bookCarRepository;

    @Autowired
    private BookVanRepository bookVanRepository;

    @Autowired
    private BookBusRepository bookBusRepository;

    @Autowired
    private BookMotorbikeRepository bookMotorbikeRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    MechanicRepository mechanicRepository;

    // This annotation specifies that this method should handle HTTP GET requests
// for the given URL path "/registerBookServiceCar/{id}" where {id} is a path variable.
    @GetMapping("/registerBookServiceCar/{id}")
    public ModelAndView registerNewServiceGet(BookCar bookCar, @PathVariable("id") Long idCar) {
        // Create a new ModelAndView instance with the view name "car/registerBookServiceCar".
        ModelAndView mv = new ModelAndView("car/registerBookServiceCar");

        // Add the "bookCar" object to the ModelAndView. This object can be used in the view.
        mv.addObject("bookCar", bookCar);

        // Add the "idCar" path variable value to the ModelAndView.
        mv.addObject("idCar", idCar);

        // Add the array of possible TypeService values to the ModelAndView.
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView, which will be used to render the view.
        return mv;
    }

    // This annotation specifies that this method should handle HTTP POST requests
// for the specified URL path "/registerBookServiceCar".
    @PostMapping("/registerBookServiceCar")
    public RedirectView registerNewService(@ModelAttribute BookCar bookCar, @RequestParam("id") Long idClient,
            @ModelAttribute("idCar") Long idCar) {

        long countCar, countVan, countBus, countMotorbike, amountBooks;

        // Retrieve the count of booked services for each vehicle type for the given day
        countCar = bookCarRepository.findBookCarByday(bookCar.getStatusService(), bookCar.getDateService());
        countVan = bookVanRepository.findBookVanByday(bookCar.getStatusService(), bookCar.getDateService());
        countBus = bookBusRepository.findBookBusByday(bookCar.getStatusService(), bookCar.getDateService());
        countMotorbike = bookMotorbikeRepository.findBookMotorbikeByday(bookCar.getStatusService(), bookCar.getDateService());

        // Calculate the total amount of booked services for all vehicle types
        amountBooks = countCar + countVan + countBus + countMotorbike;
        System.out.println("Amount of booked services: " + amountBooks);

        // Check if the maximum booking limit (6) for the day has been reached
        if (amountBooks == 6) {
            System.out.println("There are no available bookings for this day!");
        } else {
            // Retrieve the client based on the provided idClient
            Client client = clientRepository.findById(idClient)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));
            bookCar.setClient(client);

            // Retrieve the car based on the provided idCar
            Car car = carRepository.findById(idCar)
                    .orElseThrow(() -> new UsernameNotFoundException("Car not found"));
            bookCar.setCar(car);

            // Set the general cost of the service based on the service type
            String typeService = bookCar.getTypeService().getTypeService();
            bookCar.setGeneralCost(bookServiceImp.checkService(typeService));

            // Save the bookCar entity to the repository
            bookCarRepository.save(bookCar);

            // Return a RedirectView to the index page
            return new RedirectView("/");
        }

        // If the maximum booking limit has been reached, return null
        return null;
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/editBookCar/{id}" where "{id}" is a placeholder for the booking ID.
    @GetMapping("/editBookCar/{id}")
    public ModelAndView editBookCar(@PathVariable("id") Long id) {

        // Create a ModelAndView object with the view name "car/editBookCar"
        ModelAndView mv = new ModelAndView("car/editBookCar");

        // Retrieve the bookCar entity from the bookCarRepository based on the provided booking ID
        // and add it as an attribute named "bookCar" to the ModelAndView
        mv.addObject("bookCar", bookCarRepository.findById(id));

        // Add the values of the StatusService enum as an attribute named "statusServices" to the ModelAndView
        mv.addObject("statusServices", StatusService.values());

        // Add the values of the TypeService enum as an attribute named "typeServices" to the ModelAndView
        mv.addObject("typeServices", TypeService.values());

        // Return the ModelAndView object with the appropriate attributes set
        return mv;
    }

    // This annotation specifies that this method should handle HTTP POST requests
// for the specified URL path "/editBookCar".
    @PostMapping("/editBookCar")
    public RedirectView editBookCar(BookCar bookCar) {

        // Create a ModelAndView object with the view name "/index"
        ModelAndView mv = new ModelAndView("/index");

        // Update the final cost of the bookCar entity using the bookServiceImp
        // to calculate the new final cost based on the extra cost and general cost.
        bookCar.setFinalCost(bookServiceImp.updateFinalCost(bookCar.getExtralCost(), bookCar.getGeneralCost()));

        // Save the updated bookCar entity to the bookCarRepository
        bookCarRepository.save(bookCar);

        // Return a RedirectView to the root path ("/") to navigate to the index page
        return new RedirectView("/");
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/editBookCarMechanicUser/{id}".
    @GetMapping("/editBookCarMechanicUser/{id}")
    public ModelAndView editBookCarMechanicUser(@PathVariable("id") Long id) {

        // Create a ModelAndView object with the view name "car/editBookCar"
        ModelAndView mv = new ModelAndView("car/editBookCar");

        // Retrieve the BookCar entity by its ID from the bookCarRepository
        // and add it to the ModelAndView as an attribute named "bookCar".
        mv.addObject("bookCar", bookCarRepository.findById(id));

        // Add the possible values of StatusService enum as an attribute named "statusServices".
        mv.addObject("statusServices", StatusService.values());

        // Add the possible values of TypeService enum as an attribute named "typeServices".
        mv.addObject("typeServices", TypeService.values());

        // Retrieve a list of all mechanics from the mechanicRepository
        // and add it to the ModelAndView as an attribute named "mechanics".
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView object to render the editBookCar view template.
        return mv;
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/editBookCarAdminUser/{id}".
    @GetMapping("/editBookCarAdminUser/{id}")
    public ModelAndView updateStatusBookBus(@PathVariable("id") Long id) {

        // Create a ModelAndView object with the view name "car/editBookCar"
        ModelAndView mv = new ModelAndView("car/editBookCar");

        // Retrieve the BookCar entity by its ID from the bookCarRepository
        // and add it to the ModelAndView as an attribute named "bookCar".
        mv.addObject("bookCar", bookCarRepository.findById(id));

        // Add the possible values of StatusService enum as an attribute named "statusServices".
        mv.addObject("statusServices", StatusService.values());

        // Add the possible values of TypeService enum as an attribute named "typeServices".
        mv.addObject("typeServices", TypeService.values());

        // Retrieve a list of all mechanics from the mechanicRepository
        // and add it to the ModelAndView as an attribute named "mechanics".
        mv.addObject("mechanics", mechanicRepository.findAll());

        // Return the ModelAndView object to render the editBookCar view template.
        return mv;
    }

    @GetMapping("/listCarBooked")
    public ModelAndView listCarBooked() {

        ModelAndView mv = new ModelAndView("/car/listCarBooked");
        mv.addObject("bookCars", bookCarRepository.findAll());
        return mv;
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/deleteBookCar/{id}".
    @GetMapping("/deleteBookCar/{id}")
    public RedirectView deleteBookCar(@PathVariable("id") Long id) {

        // Create a ModelAndView object with the view name "/index".
        ModelAndView mv = new ModelAndView("/index");

        // Delete the BookCar entity by its ID from the bookCarRepository.
        bookCarRepository.deleteById(id);

        // Return a RedirectView to the root path ("/") to refresh the page.
        return new RedirectView("/");
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/checkInvoiceBookCar/{id}".
    @GetMapping("/checkInvoiceBookCar/{id}")
    public ModelAndView checkInoiceCarBooked(@PathVariable("id") Long id) {

        // Create a ModelAndView object with the view name "car/invoiceBookCar".
        ModelAndView mv = new ModelAndView("car/invoiceBookCar");

        // Add an attribute named "bookCar" to the ModelAndView, containing a list of all car bookings.
        // The list is obtained from the bookCarRepository by calling findAll() method.
        mv.addObject("bookCar", bookCarRepository.findAll());

        // Return the ModelAndView to display the invoice for the booked car.
        return mv;
    }

    // This annotation specifies that this method should handle HTTP GET requests
// for the specified URL path "/generateInvoiceBookCar/{id}".
    @GetMapping("/generateInvoiceBookCar/{id}")
    public void exportToPDF(HttpServletResponse response, @PathVariable("id") Long id) throws DocumentException, IOException {
        // Set the content type of the HTTP response to indicate that a PDF file will be returned.
        response.setContentType("application/pdf");

        // Define the date format to be used in the generated PDF file name.
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        // Set the HTTP response header to specify the file attachment.
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=invoice" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);

        // Retrieve the booked car using the provided "id" parameter.
        // If the car is not found, throw a "User not found" exception.
        BookCar bookCar = bookCarRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Create an instance of the GenerateBookCarInvoicePDF class, passing the booked car as a parameter.
        GenerateBookCarInvoicePDF exporter = new GenerateBookCarInvoicePDF(bookCar);

        // Call the export method of the exporter to generate and export the PDF invoice.
        exporter.export(response);
    }

}
