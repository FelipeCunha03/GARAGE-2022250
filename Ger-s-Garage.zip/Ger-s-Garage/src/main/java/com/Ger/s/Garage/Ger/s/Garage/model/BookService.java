/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author felipecunha
 */

// The following annotations are used:
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
// - @MappedSuperclass: Indicates that this class is a mapped superclass, meaning it provides common attributes for subclasses but is not itself a persistent entity.
@Getter
@Setter
@MappedSuperclass
public abstract class BookService {

    // Represents the unique identifier for a booked service
    @Column
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    // Enumerated type representing the type of service being booked (e.g., Car, Bus, Motorbike, etc.)
    @Enumerated(EnumType.STRING)
    private TypeService typeService;

    // Details about the booked service
    private String details;

    // Time at which the service is scheduled
    private String timeIn;

    // Date on which the service is scheduled
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date dateService;

    // Enumerated type representing the status of the booked service (e.g., Pending, Completed, etc.)
    @Enumerated(EnumType.STRING)
    private StatusService statusService;

    // Constructor for creating a new BookService instance with specified attributes
    public BookService(TypeService typeService, String details, String timeIn, Date dateService, StatusService statusService) {
        this.typeService = typeService;
        this.details = details;
        this.timeIn = timeIn;
        this.dateService = dateService;
        this.statusService = statusService;
    }

    // Default constructor for the BookService class
    public BookService() {
    }
}

