/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum MotorbikeMakes {

    BMWMotorrad("BMWMotorrad"),
    Ducati("Ducati"),
    Triumph("Triumph"),
    KTM("KTM"),
    MVAgusta("MVAgusta"),
    Husqvarna("Husqvarna"),
    MotoGuzzi("MotoGuzzi");

    private String motorbikeMakes;

    private MotorbikeMakes(String MotorbikeMakes) {
        this.motorbikeMakes = MotorbikeMakes;
    }

    public String getMotorbikeMakes() {
        return motorbikeMakes;
    }

    public void setMotorbikeMakes(String MotorbikeMakes) {
        this.motorbikeMakes = MotorbikeMakes;
    }

}
