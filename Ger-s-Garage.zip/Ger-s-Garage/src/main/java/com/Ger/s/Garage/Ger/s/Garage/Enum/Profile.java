/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum Profile {

    ADM("ADM"),
    MECHANIC("MECHANIC"),
    CLIENT("CLIENT");

    private Profile(String profile) {
        this.profile = profile;
    }

    private String profile;

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

}
