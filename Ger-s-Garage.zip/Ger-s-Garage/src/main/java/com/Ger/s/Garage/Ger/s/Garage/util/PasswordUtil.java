package com.Ger.s.Garage.Ger.s.Garage.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordUtil {

    // This method encodes (hashes) the given password using BCrypt
    public static String encoder(String password){
        // Create an instance of BCryptPasswordEncoder
        BCryptPasswordEncoder encoderPasswod = new BCryptPasswordEncoder();
        
        // Encode the password and return the hashed result
        return encoderPasswod.encode(password);
    }
}
