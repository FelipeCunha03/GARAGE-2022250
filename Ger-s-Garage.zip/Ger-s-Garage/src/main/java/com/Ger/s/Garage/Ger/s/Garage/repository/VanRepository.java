package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Van;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Van entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom query method for finding Van entities by client ID.
 */
@Repository
public interface VanRepository extends JpaRepository<Van, Long> {
    
    /**
     * Find Van entities by client ID.
     * @param clientId the ID of the client
     * @return a list of Van entities associated with the specified client ID
     */
    @Query("select b from Van b where b.client.id = :clientId")
    List<Van> findByClientId(Long clientId);
}
