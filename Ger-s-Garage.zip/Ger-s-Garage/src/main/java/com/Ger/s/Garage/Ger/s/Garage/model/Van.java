/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.VanMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.VanTypes;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Specifies that this class is a JPA entity and will be mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_VAN")
public class Van extends Vehicles {

    // Represents the capacity of passengers in the van
    private Integer capacityPassengers;

    // Represents the number of doors in the van
    private Integer numberDoor;

    // Represents the make (brand) of the van (e.g., Ford, Toyota)
    @Enumerated(EnumType.STRING)
    private VanMakes vanMake;

    // Represents the type of the van (e.g., Cargo, Passenger)
    @Enumerated(EnumType.STRING)
    private VanTypes vanType;

    // Constructor for creating a new Van instance with specified attributes
    public Van(Integer capacityPassengers, Integer numberDoor, VanMakes vanMakes, VanTypes vanTypes, Client client, Integer year, String color, String plate, EngineTypes engineType) {
        super(year, color, plate, engineType);
        this.capacityPassengers = capacityPassengers;
        this.numberDoor = numberDoor;
        this.vanMake = vanMakes;
        this.vanType = vanTypes;
        this.client = client;
    }

    // Default constructor for the Van class
    public Van() {
    }

    // Represents the association between a van and a client (many vans can belong to one client)
    @ManyToOne
    @JoinColumn(name = "client_id_fk")
    private Client client;

}

