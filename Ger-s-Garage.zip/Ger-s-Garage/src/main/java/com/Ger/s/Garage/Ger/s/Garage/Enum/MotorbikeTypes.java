/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.Enum;

/**
 *
 * @author felipecunha
 */
public enum MotorbikeTypes {

    // list of types of motorbikes from  BMWMotorrad
    BMWMotorradR1250GS("BMWMotorradR1250GS"),
    BMWMotorradRnineT("BMWMotorradRnineT"),
    BMWMotorradS1000RR("BMWMotorradS1000RR"),
    BMWMotorradF750GS("BMWMotorradF750GS"),
    BMWMotorradF850GS("BMWMotorradF850GS"),
    BMWMotorradG310R("BMWMotorradG310R"),
    BMWMotorradG310GS("BMWMotorradG310GS"),
    BMWMotorradK1600GTL("BMWMotorradK1600GTL"),
    BMWMotorradR18("BMWMotorradR18"),
    BMWMotorradC650GT("BMWMotorradC650GT"),
    // list of types of motorbikes from  Ducatil
    DucatiPanigale("DucatiPanigale"),
    DucatiMonster("DucatiMonster"),
    DucatiScrambler("DucatiScrambler"),
    DucatiDiavel("DucatiDiavel"),
    DucatiMultistrada("DucatiMultistrada"),
    DucatiHypermotard("DucatiHypermotard"),
    DucatiSuperSport("DucatiSuperSport"),
    DucatiStreetfighter("DucatiStreetfighter"),
    DucatiXDiavel("DucatiXDiavel"),
    DucatiDesmosediciRR("DucatiDesmosediciRR"),
    // list of types of motorbikes from  Triumph
    TriumphBonneville("TriumphBonneville"),
    TriumphStreetTriple("TriumphStreetTriple"),
    TriumphTiger("TriumphTiger"),
    TriumphSpeedTriple("TriumphSpeedTriple"),
    TriumphThruxton("TriumphThruxton"),
    TriumphRocket("TriumphRocket"),
    TriumphScrambler("TriumphScrambler"),
    TriumphDaytona("TriumphDaytona"),
    TriumphTrident("TriumphTrident"),
    TriumphTigerExplorer("TriumphTigerExplorer"),
    // list of types of motorbikes from  KTM
    KTMDuke("KTMDuke"),
    KTMRC("KTMRC"),
    KTMSuperDuke("KTMSuperDuke"),
    KTMEnduro("KTMEnduro"),
    KTMMotocross("KTMMotocross"),
    KTMFreeride("KTMFreeride"),
    KTMSupermoto("KTMSupermoto"),
    KTMSX("KTMSX"),
    KTMEXC("KTMEXC"),
    // list of types of motorbikes from  MVAgusta
    MVAgustaF4("KTMDuke"),
    MVAgustaBrutale("MVAgustaBrutale"),
    MVAgustaDragster("MVAgustaDragster"),
    MVAgustaTurismoVeloce("MVAgustaTurismoVeloce"),
    MVAgustaRivale("MVAgustaRivale"),
    MVAgustaSuperveloce("MVAgustaSuperveloce"),
    MVAgustaStradale("MVAgustaStradale"),
    MVAgustaF3("MVAgustaF3"),
    MVAgustaBrutaleRR("MVAgustaBrutaleRR"),
    MVAgustaDragsterRR("MVAgustaDragsterRR"),
    // list of types of motorbikes from  Husqvarna
    HusqvarnaFC("HusqvarnaFC"),
    HusqvarnaFE("HusqvarnaFE"),
    HusqvarnaFX("HusqvarnaFX"),
    HusqvarnaTC("HusqvarnaTC"),
    HusqvarnaVitpilen("HusqvarnaVitpilen"),
    HusqvarnaNuda("HusqvarnaNuda"),
    HusqvarnaStrada("HusqvarnaStrada"),
    // list of types of motorbikes from  MotoGuzzi
    MotoGuzziV7("MotoGuzziV7"),
    MotoGuzziV9("MotoGuzziV9"),
    MotoGuzziV85TT("MotoGuzziV85TT"),
    MotoGuzziCalifornia("MotoGuzziCalifornia"),
    MotoGuzziAudace("MotoGuzziAudace"),
    MotoGuzziEldorado("MotoGuzziEldorado"),
    MotoGuzziMGX21("MotoGuzziMGX21"),
    MotoGuzziGriso("MotoGuzziGriso"),
    MotoGuzziStelvio("MotoGuzziStelvio"),
    MotoGuzziBreva("MotoGuzziBreva");

    private String motorbikesType;

    private MotorbikeTypes(String MotorbikesType) {
        this.motorbikesType = MotorbikesType;
    }

    public String getMotorbikesType() {
        return motorbikesType;
    }

    public void setMotorbikesType(String MotorbikesType) {
        this.motorbikesType = MotorbikesType;
    }

}
