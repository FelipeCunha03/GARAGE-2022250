/*
 * This interface defines the contract for user details required by the authentication and authorization process.
 */
package com.Ger.s.Garage.Ger.s.Garage.Service;

import java.io.Serializable;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;

/**
 * Custom interface for user details required by authentication and authorization.
 */
public interface UserDetails extends Serializable {

    // Get the authorities (roles) associated with the user
    public Collection<? extends GrantedAuthority> getAuthorities();

    // Get the user's password
    public String getPassword();

    // Get the user's username (usually email)
    public String getUsername();

    // Check if the user's account is not expired
    public boolean isAccountNonExpired();

    // Check if the user's account is not locked
    public boolean isAccountNonLocked();

    // Check if the user's credentials are not expired
    public boolean isCredentialsNonExpired();

    // Check if the user's account is enabled
    public boolean isEnabled();
}
