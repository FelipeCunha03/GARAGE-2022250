/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.StatusService;
import com.Ger.s.Garage.Ger.s.Garage.Enum.TypeService;
import javax.persistence.*;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity, representing a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
public class BookBus extends BookService {

    // Many-to-One relationship with the "Bus" entity, using a foreign key column named "bus_id_fk"
    @ManyToOne
    @JoinColumn(name = "bus_id_fk")
    private Bus bus;

    // Many-to-One relationship with the "Mechanic" entity, using a foreign key column named "mechanic_id_fk"
    @ManyToOne
    @JoinColumn(name = "mechanic_id_fk")
    private Mechanic mechanic;

    // Many-to-One relationship with the "Client" entity, using a foreign key column named "client_id_fk"
    @ManyToOne
    @JoinColumn(name = "client_id_fk")
    private Client client;

    // Fields to store cost and details of the bus service booking
    private double generalCost;
    private double extralCost;
    private String busServiceDetails;
    private double finalCost;

    // Constructor for creating a new BookBus instance with specified attributes
    public BookBus(Bus bus, Mechanic mechanic, Client client, double generalCost, double extralCost, String busServiceDetails, double finalCost, TypeService typeService, String details, String timeIn, Date dateService, StatusService statusService) {
        // Call the constructor of the parent class ("BookService") to set common attributes
        super(typeService, details, timeIn, dateService, statusService);
        this.bus = bus;
        this.mechanic = mechanic;
        this.client = client;
        this.generalCost = generalCost;
        this.extralCost = extralCost;
        this.busServiceDetails = busServiceDetails;
        this.finalCost = finalCost;
    }

    // Default constructor for the BookBus class
    public BookBus() {
    }
}
