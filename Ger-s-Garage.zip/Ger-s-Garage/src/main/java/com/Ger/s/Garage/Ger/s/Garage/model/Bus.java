/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.model;

import com.Ger.s.Garage.Ger.s.Garage.Enum.BusMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.BusTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 *
 * @author felipecunha
 */
// The following annotations are used:
// - @Entity: Indicates that this class is a JPA entity and is mapped to a database table.
// - @Getter: Generates getter methods for all non-static fields in the class.
// - @Setter: Generates setter methods for all non-static fields in the class.
@Entity
@Getter
@Setter
@Table(name = "TB_BUS") // Specifies the name of the database table
public class Bus extends Vehicles {

    // Represents the number of doors of the bus
    private Integer numberDoors;

    // Represents the capacity of passengers the bus can carry
    private Integer capacityPassengers;

    // Represents the make (brand) of the bus (Enum: BusMakes)
    @Enumerated(EnumType.STRING)
    private BusMakes busMake;

    // Represents the type of the bus (Enum: BusTypes)
    @Enumerated(EnumType.STRING)
    private BusTypes busType;

    // Represents the associated client (owner) of the bus
    @ManyToOne
    @JoinColumn(name = "client_id_fk") // Specifies the foreign key column
    private Client client;

    // Constructor for creating a new Bus instance with specified attributes
    public Bus(Integer numberDoors, Integer capacityPassengers, BusMakes busMake, BusTypes busType, Client client, Integer year, String color, String plate, EngineTypes engineType) {
        // Call the constructor of the superclass (Vehicles) to initialize common vehicle attributes
        super(year, color, plate, engineType);
        this.numberDoors = numberDoors;
        this.capacityPassengers = capacityPassengers;
        this.busMake = busMake;
        this.busType = busType;
        this.client = client;
    }

    // Default constructor for the Bus class
    public Bus() {
    }
}
