package com.Ger.s.Garage.Ger.s.Garage.repository;

import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for managing Client entities.
 * This interface extends JpaRepository, providing basic CRUD operations.
 * Additionally, it defines a custom query method for finding a Client entity by email.
 */
@Repository
public interface ClientRepository extends JpaRepository<Client, Long> {  

    /**
     * Find a Client entity by its email.
     * @param email the email of the client
     * @return an Optional containing the Client entity if found
     */
    Optional<Client> findByEmail(String email);
}
