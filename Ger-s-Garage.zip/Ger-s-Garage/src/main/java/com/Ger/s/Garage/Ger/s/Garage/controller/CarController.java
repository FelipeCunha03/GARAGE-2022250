/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.Ger.s.Garage.Ger.s.Garage.controller;

import com.Ger.s.Garage.Ger.s.Garage.Enum.CarMakes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.CarTypes;
import com.Ger.s.Garage.Ger.s.Garage.Enum.EngineTypes;
import com.Ger.s.Garage.Ger.s.Garage.model.Car;
import com.Ger.s.Garage.Ger.s.Garage.model.Client;
import com.Ger.s.Garage.Ger.s.Garage.repository.CarRepository;
import com.Ger.s.Garage.Ger.s.Garage.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author felipecunha
 * CarController, responsible for handling various operations related to buses in a garage application
 */
@Controller
@RequestMapping("/car")
public class CarController {

     // Autowired repositories for accessing data
    @Autowired
    CarRepository carRepository;

    @Autowired
    ClientRepository clientRepository;

    // Handler for GET request to register a new car
@GetMapping("/RegisterCar")
public ModelAndView registerCarGet(Car car) {
    // Create a new ModelAndView object for the "RegisterCar" view
    ModelAndView mv = new ModelAndView("car/RegisterCar");
    
    // Add the "car" object to the ModelAndView, allowing form binding and input
    mv.addObject("car", car);
    
    // Add lists of available car attributes to the ModelAndView
    mv.addObject("carMakes", CarMakes.values());     // Enum values for car makes
    mv.addObject("carTypes", CarTypes.values());     // Enum values for car types
    mv.addObject("engineTypes", EngineTypes.values()); // Enum values for engine types
    
    // Return the ModelAndView object to render the "RegisterCar" view
    return mv;
}


    // Handler for POST request to register a new car
@PostMapping("/RegisterCar")
public RedirectView registerCar(@ModelAttribute Car car, @RequestParam("id") Long id) {
    // Retrieve the client by id from the client repository
    Client client = clientRepository.findById(id)
            .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    
    // Set the client for the car
    car.setClient(client);

    // Save the car in the car repository
    carRepository.save(car);
    
    // Redirect to the home page ("/") after successful registration
    return new RedirectView("/");
}


    // Handler for GET request to edit a car
@GetMapping("/editCar/{id}")
public ModelAndView editCar(@PathVariable("id") Long id) {
    // Create a ModelAndView object with the view name "car/editCar"
    ModelAndView mv = new ModelAndView("car/editCar");
    
    // Retrieve the car by id from the car repository
    Car car = carRepository.findById(id)
            .orElseThrow(() -> new UsernameNotFoundException("Car not found"));
    
    // Add attributes to the ModelAndView for use in the view
    mv.addObject("car", car); // The car to be edited
    mv.addObject("carMakes", CarMakes.values()); // Available car makes (enum values)
    mv.addObject("carTypes", CarTypes.values()); // Available car types (enum values)
    mv.addObject("engineTypes", EngineTypes.values()); // Available engine types (enum values)

    return mv;
}


    // Handler for POST request to update a car
@PostMapping("/editCar")
public RedirectView editCar(Car car) {
    // Save the updated car object to the car repository
    carRepository.save(car);

    // Redirect to the root URL ("/") after the update
    return new RedirectView("/");
}

    
    

    // Handler for GET request to delete a car
@GetMapping("/deleteCar/{id}")
public RedirectView deleteCar(@PathVariable("id") Long id) {
    // Delete the car with the specified ID from the car repository
    carRepository.deleteById(id);

    // Redirect to the root URL ("/") after the car is deleted
    return new RedirectView("/");
}


    @GetMapping("/listCar")
    public ModelAndView listCars(@RequestParam("id") Long id) {
        ModelAndView mv = new ModelAndView("/car/listCar");
        mv.addObject("cars", carRepository.findByClientId(id));
        return mv;
    }

}
